package social.socialtap.core;

/** The few things the shared code needs from the game. */
public interface Host {
	/** Opens a URL in the player's default browser. */
	void openUrl(String url);
}
