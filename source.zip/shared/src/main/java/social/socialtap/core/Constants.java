package social.socialtap.core;

public final class Constants {
	/**
	 * The Social Tap OAuth client ID (Profile -> Developer dashboard). It is public: there is no
	 * client secret. Leave the placeholder to read "client_id" from config/socialtap.json instead.
	 */
	public static final String CLIENT_ID = "stu_-HPJ3V85bo7Mvx2LIdPiyxQiQX90IjtCiZndAPYvwv8";

	public static final String BASE_URL = "https://www.socialtap.social";

	/** Must match the redirect URI registered for the client, character for character. */
	public static final int CALLBACK_PORT = 38917;
	public static final String REDIRECT_URI = "http://127.0.0.1:" + CALLBACK_PORT + "/callback";

	/** Must match the scopes configured for the client in the developer dashboard. */
	public static final String SCOPES = "chat.read voice.call voice.audio";

	public static final String USER_AGENT = "SocialTap-Minecraft/1.0";

	private Constants() {
	}
}
