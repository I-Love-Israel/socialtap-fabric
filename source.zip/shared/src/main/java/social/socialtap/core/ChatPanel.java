package social.socialtap.core;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/**
 * The Social Tap window: chats down the left, the open chat on the right, a message box along the
 * bottom and call buttons in the chat header, in the manner of a voice-chat overlay. Shared by every
 * Minecraft version; each version's screen forwards drawing, clicks, scrolling and typing here.
 * Everything runs on the client thread and coordinates are GUI pixels.
 */
public final class ChatPanel {
	// GLFW key codes and modifier bits, so this file needs nothing from the game.
	private static final int KEY_ENTER = 257;
	private static final int KEY_KP_ENTER = 335;
	private static final int KEY_BACKSPACE = 259;
	private static final int KEY_DELETE = 261;
	private static final int KEY_RIGHT = 262;
	private static final int KEY_LEFT = 263;
	private static final int KEY_DOWN = 264;
	private static final int KEY_UP = 265;
	private static final int KEY_PAGE_UP = 266;
	private static final int KEY_PAGE_DOWN = 267;
	private static final int KEY_HOME = 268;
	private static final int KEY_END = 269;
	private static final int KEY_V = 86;
	private static final int MOD_CONTROL = 0x2;
	private static final int MOD_ALT = 0x4;

	private static final int DIM = 0x88000000;
	private static final int SIDEBAR = 0xF22B2D31;
	private static final int MAIN = 0xF2313338;
	private static final int LINE = 0xFF1F2023;
	private static final int ROW_HOVER = 0xFF35373C;
	private static final int ROW_SELECTED = 0xFF404249;
	private static final int INPUT = 0xFF383A40;
	private static final int TEXT = 0xFFDBDEE1;
	private static final int WHITE = 0xFFF2F3F5;
	private static final int MUTED = 0xFF949BA4;
	private static final int FAINT = 0xFF6D6F78;
	private static final int BLURPLE = 0xFF5865F2;
	private static final int MINE = 0xFFA5ACF7;
	private static final int GREEN = 0xFF23A559;
	private static final int RED = 0xFFDA373C;
	private static final int GREY_BUTTON = 0xFF4E5058;
	private static final int FONT = 9;
	private static final int ROW = 16;
	private static final int MAX_LENGTH = 500;

	private final SocialTapService service;
	private final Supplier<String> clipboard;
	private String keyName = "`";

	// Message box.
	private String input = "";
	private int cursor;
	private int inputScroll;
	// Set from the background thread too, hence volatile; a failed send hands its text back here.
	private volatile String notice = "";
	private volatile long noticeUntilMs;
	private volatile boolean sending;
	private volatile String unsent;

	// Scrolling: chat list from the top, messages from the bottom (0 = newest in view).
	private int listScroll;
	private int messageScroll;

	// Laid-out history, kept while the messages and width stay the same.
	private List<ChatHistoryRow> rows = List.of();
	private List<SocialTapService.ChatMessage> rowsFor;
	private int rowsWidth = -1;

	// Hit boxes from the last frame: {x1, y1, x2, y2}.
	private int[] panelBox;
	private int[] listBox;
	private int[] messageBox;
	private int[] inputBox;
	private int[] callButton;
	private int[] webButton;
	private final List<long[]> chatRows = new ArrayList<>(); // {chatId, x1, y1, x2, y2}
	private int inputTextX;
	private Overlay.Canvas lastCanvas;

	private record ChatHistoryRow(String text, String time, int color, boolean header, int height) {
	}

	public ChatPanel(SocialTapService service, Supplier<String> clipboard) {
		this.service = service;
		this.clipboard = clipboard;
	}

	/** The open/close key's name, for the hint at the bottom of the chat list. */
	public void setKeyName(String keyName) {
		if (keyName != null && !keyName.isBlank()) this.keyName = keyName;
	}

	public void opened() {
		service.panelOpened();
		if (service.viewedChat() < 0) {
			// Start on the chat that most wants attention, or the first one.
			SocialTapService.ChatInfo pick = null;
			for (SocialTapService.ChatInfo chat : service.chats()) {
				if (pick == null || chat.unread() > 0 && pick.unread() == 0) pick = chat;
			}
			if (pick != null) select(pick.id());
		}
	}

	public void closed() {
		service.panelClosed();
	}

	public boolean inputEmpty() {
		return input.isEmpty();
	}

	// ---- drawing ----

	public void render(Overlay.Canvas canvas, int mouseX, int mouseY) {
		lastCanvas = canvas;
		long now = System.currentTimeMillis();
		String failed = unsent;
		if (failed != null) {
			// Give the text back so it is not lost, unless something new was typed meanwhile.
			unsent = null;
			if (input.isEmpty()) {
				input = failed;
				cursor = failed.length();
			}
		}
		int width = canvas.width();
		int height = canvas.height();
		canvas.fill(0, 0, width, height, DIM);

		// Leave the top free for the call box while a call is on.
		int top = service.overlay().active() != null ? 40 : 10;
		int panelWidth = Math.min(width - 16, 560);
		int x1 = (width - panelWidth) / 2;
		int x2 = x1 + panelWidth;
		int y1 = Math.min(top, height / 4);
		int y2 = height - 10;
		panelBox = new int[] {x1, y1, x2, y2};
		int split = x1 + Math.max(90, Math.min(150, panelWidth * 3 / 10));

		canvas.fill(x1, y1, split, y2, SIDEBAR);
		canvas.fill(split, y1, x2, y2, MAIN);
		renderChatList(canvas, x1, y1, split, y2, mouseX, mouseY);
		renderChat(canvas, split, y1, x2, y2, mouseX, mouseY, now);
	}

	private void renderChatList(Overlay.Canvas canvas, int x1, int y1, int x2, int y2, int mouseX, int mouseY) {
		// Header.
		canvas.text("SOCIAL TAP", x1 + 7, y1 + 6, 1f, WHITE);
		canvas.fill(x1, y1 + 19, x2, y1 + 20, LINE);

		// Connection state and close hint along the bottom.
		int footer = y2 - 24;
		canvas.fill(x1, footer, x2, footer + 1, LINE);
		String state = service.connectionState();
		boolean connected = service.connected();
		canvas.fill(x1 + 7, footer + 6, x1 + 11, footer + 10, connected ? GREEN : state.endsWith("...") ? 0xFFF0B232 : RED);
		canvas.text(ellipsize(canvas, state, x2 - x1 - 20, 1f), x1 + 15, footer + 4, 1f, connected ? MUTED : WHITE);
		String hint = keyName + " or Esc to close";
		canvas.text(ellipsize(canvas, hint, (int) ((x2 - x1 - 14) / 0.75f), 0.75f), x1 + 7, footer + 15, 0.75f, FAINT);

		// The chats.
		int areaTop = y1 + 22;
		int areaBottom = footer - 2;
		listBox = new int[] {x1, areaTop, x2, areaBottom};
		chatRows.clear();
		List<SocialTapService.ChatInfo> chats = service.chats();
		int contentHeight = chats.size() * ROW;
		listScroll = Math.max(0, Math.min(listScroll, Math.max(0, contentHeight - (areaBottom - areaTop))));
		if (chats.isEmpty()) {
			String empty = service.connected() ? "No chats yet" : "Waiting for Social Tap...";
			canvas.text(ellipsize(canvas, empty, x2 - x1 - 14, 1f), x1 + 7, areaTop + 4, 1f, FAINT);
			return;
		}
		long open = service.viewedChat();
		canvas.clip(x1, areaTop, x2, areaBottom);
		int y = areaTop - listScroll;
		for (SocialTapService.ChatInfo chat : chats) {
			if (y + ROW > areaTop && y < areaBottom) {
				int rx1 = x1 + 4;
				int rx2 = x2 - 4;
				boolean hover = inside(new int[] {rx1, Math.max(y, areaTop), rx2, Math.min(y + ROW - 1, areaBottom)}, mouseX, mouseY);
				if (chat.id() == open) canvas.fill(rx1, y, rx2, y + ROW - 1, ROW_SELECTED);
				else if (hover) canvas.fill(rx1, y, rx2, y + ROW - 1, ROW_HOVER);

				// Icon: "#" for groups, a presence dot for people.
				int textY = y + (ROW - 1 - FONT) / 2 + 1;
				if (chat.group()) {
					canvas.text("#", rx1 + 3, textY, 1f, MUTED);
				} else {
					canvas.fill(rx1 + 3, y + 5, rx1 + 8, y + 10, chat.online() ? GREEN : FAINT);
				}
				int badgeWidth = 0;
				if (chat.unread() > 0) {
					String count = chat.unread() > 99 ? "99+" : String.valueOf(chat.unread());
					badgeWidth = canvas.textWidth(count) + 6;
					canvas.fill(rx2 - 3 - badgeWidth, y + 3, rx2 - 3, y + ROW - 4, RED);
					canvas.text(count, rx2 - 3 - badgeWidth + 3, textY, 1f, WHITE);
				}
				int nameX = rx1 + 12;
				int color = chat.id() == open || chat.unread() > 0 ? WHITE : MUTED;
				canvas.text(ellipsize(canvas, chat.name(), rx2 - nameX - badgeWidth - 6, 1f), nameX, textY, 1f, color);
				chatRows.add(new long[] {chat.id(), rx1, Math.max(y, areaTop), rx2, Math.min(y + ROW - 1, areaBottom)});
			}
			y += ROW;
		}
		canvas.endClip();
	}

	private void renderChat(Overlay.Canvas canvas, int x1, int y1, int x2, int y2, int mouseX, int mouseY, long now) {
		callButton = webButton = inputBox = messageBox = null;
		SocialTapService.ChatInfo chat = currentChat();
		if (chat == null) {
			String hint = service.chats().isEmpty() ? "Your Social Tap chats will show up here." : "Pick a chat on the left.";
			centered(canvas, hint, (x1 + x2) / 2f, (y1 + y2) / 2f - 4, MUTED);
			return;
		}

		// Header: who, and the buttons.
		int headerBottom = y1 + 20;
		canvas.fill(x1, headerBottom - 1, x2, headerBottom, LINE);
		int bx2 = x2 - 6;
		webButton = button(canvas, "Web", bx2, y1 + 3, GREY_BUTTON, mouseX, mouseY);
		bx2 = webButton[0] - 4;
		Overlay.ActiveCall call = service.overlay().active();
		if (call != null && call.chatId == chat.id()) {
			callButton = button(canvas, call.connected ? "Hang up" : "Cancel", bx2, y1 + 3, RED, mouseX, mouseY);
		} else if (chat.callable()) {
			callButton = button(canvas, "Call", bx2, y1 + 3, call == null ? GREEN : GREY_BUTTON, mouseX, mouseY);
		}
		int nameRight = (callButton != null ? callButton[0] : webButton[0]) - 6;
		String prefix = chat.group() ? "# " : "@ ";
		canvas.text(prefix, x1 + 8, y1 + 6, 1f, FAINT);
		int nameX = x1 + 8 + canvas.textWidth(prefix);
		canvas.text(ellipsize(canvas, chat.name(), nameRight - nameX, 1f), nameX, y1 + 6, 1f, WHITE);

		// Message box along the bottom.
		int ib1 = y2 - 22;
		int ib2 = y2 - 6;
		inputBox = new int[] {x1 + 8, ib1, x2 - 8, ib2};
		canvas.fill(x1 + 8, ib1, x2 - 8, ib2, INPUT);
		renderInput(canvas, chat, x1 + 14, ib1 + 4, x2 - 14 - (x1 + 14), now);

		// A failed send or similar, just above the box.
		int messagesBottom = ib1 - 4;
		String shownNotice = notice;
		if (!shownNotice.isEmpty() && now < noticeUntilMs) {
			canvas.text(ellipsize(canvas, shownNotice, x2 - x1 - 16, 1f), x1 + 8, ib1 - 12, 1f, RED);
			messagesBottom = ib1 - 16;
		}

		// The history.
		int mx1 = x1 + 8;
		int mx2 = x2 - 8;
		int messagesTop = headerBottom + 2;
		messageBox = new int[] {x1, messagesTop, x2, messagesBottom};
		SocialTapService.History history = service.viewedHistory();
		if (history == null || history.chatId != chat.id()) return;
		List<SocialTapService.ChatMessage> messages = history.messages;
		if (messages.isEmpty()) {
			String text = history.loading ? "Loading messages..." : !history.error.isEmpty() ? history.error : "No messages yet. Say hi!";
			centered(canvas, ellipsize(canvas, text, mx2 - mx1, 1f), (x1 + x2) / 2f, (messagesTop + messagesBottom) / 2f - 4,
					history.error.isEmpty() ? MUTED : RED);
			return;
		}
		if (messages != rowsFor || rowsWidth != mx2 - mx1) {
			rows = layout(canvas, messages, mx2 - mx1);
			rowsFor = messages;
			rowsWidth = mx2 - mx1;
		}
		int total = 0;
		for (ChatHistoryRow row : rows) total += row.height();
		int area = messagesBottom - messagesTop;
		messageScroll = Math.max(0, Math.min(messageScroll, Math.max(0, total - area)));
		canvas.clip(x1, messagesTop, x2, messagesBottom);
		int y = messagesBottom - total + messageScroll;
		for (ChatHistoryRow row : rows) {
			if (y + row.height() > messagesTop && y < messagesBottom) {
				int textY = y + row.height() - FONT - (row.header() ? 1 : 0);
				canvas.text(row.text(), mx1, textY, 1f, row.color());
				if (row.header() && !row.time().isEmpty()) {
					canvas.text(row.time(), mx1 + canvas.textWidth(row.text()) + 5, textY + 1.5f, 0.75f, FAINT);
				}
			}
			y += row.height();
		}
		canvas.endClip();
		if (messageScroll > 0) {
			canvas.layer(); // over the message text
			// Scrolled up: say so, and how to get back.
			String back = "Scrolled up · PgDn for newest";
			int w = (int) (canvas.textWidth(back) * 0.75f) + 8;
			canvas.fill(x2 - 8 - w, messagesBottom - 11, x2 - 8, messagesBottom - 1, BLURPLE);
			canvas.text(back, x2 - 4 - w, messagesBottom - 9, 0.75f, WHITE);
		}
	}

	private void renderInput(Overlay.Canvas canvas, SocialTapService.ChatInfo chat, int x, int y, int width, long now) {
		inputTextX = x;
		if (input.isEmpty()) {
			String placeholder = sending ? "Sending..." : "Message " + (chat.group() ? "#" : "@") + chat.name();
			canvas.text(ellipsize(canvas, placeholder, width, 1f), x, y, 1f, FAINT);
			if ((now / 500) % 2 == 0 && !sending) canvas.fill(x, y - 1, x + 1, y + FONT, WHITE);
			return;
		}
		// Keep the cursor in view: slide the visible part of the text.
		if (cursor < inputScroll) inputScroll = cursor;
		while (inputScroll < cursor && canvas.textWidth(input.substring(inputScroll, cursor)) > width - 2) inputScroll++;
		int end = inputScroll;
		while (end < input.length() && canvas.textWidth(input.substring(inputScroll, end + 1)) <= width) end++;
		canvas.text(input.substring(inputScroll, end), x, y, 1f, WHITE);
		if ((now / 500) % 2 == 0) {
			int cx = x + canvas.textWidth(input.substring(inputScroll, cursor));
			canvas.fill(cx, y - 1, cx + 1, y + FONT, WHITE);
		}
		if (input.length() > MAX_LENGTH - 50) {
			String left = String.valueOf(MAX_LENGTH - input.length());
			canvas.text(left, x + width - canvas.textWidth(left) * 0.75f, y - 9, 0.75f, input.length() >= MAX_LENGTH ? RED : FAINT);
		}
	}

	/** Groups each sender's run of messages under one name line, then wraps the text. */
	private static List<ChatHistoryRow> layout(Overlay.Canvas canvas, List<SocialTapService.ChatMessage> messages, int width) {
		List<ChatHistoryRow> out = new ArrayList<>();
		String lastSender = null;
		for (SocialTapService.ChatMessage message : messages) {
			if (!message.username().equals(lastSender) || message.note()) {
				if (!out.isEmpty()) out.add(new ChatHistoryRow("", "", 0, false, 5));
				out.add(new ChatHistoryRow(ellipsize(canvas, message.username(), width - 30, 1f), message.time(),
						message.mine() ? MINE : WHITE, true, FONT + 3));
				lastSender = message.note() ? null : message.username();
			}
			int color = message.note() ? MUTED : TEXT;
			for (String line : wrap(canvas, message.text(), width)) out.add(new ChatHistoryRow(line, "", color, false, FONT + 1));
		}
		return out;
	}

	private static int[] button(Overlay.Canvas canvas, String label, int right, int top, int color, int mouseX, int mouseY) {
		int width = canvas.textWidth(label) + 10;
		int[] box = {right - width, top, right, top + 14};
		boolean hover = inside(box, mouseX, mouseY);
		canvas.fill(box[0], box[1], box[2], box[3], hover ? brighter(color) : color);
		canvas.text(label, box[0] + 5, top + 3, 1f, WHITE);
		return box;
	}

	// ---- input ----

	public boolean mouseClicked(double x, double y, int button) {
		if (panelBox == null || !inside(panelBox, x, y)) return false;
		if (button != 0) return true;
		for (long[] row : chatRows) {
			if (x >= row[1] && x < row[3] && y >= row[2] && y < row[4]) {
				select(row[0]);
				return true;
			}
		}
		SocialTapService.ChatInfo chat = currentChat();
		if (chat != null && inside(webButton, x, y)) {
			service.openChatInBrowser(chat.id());
			return true;
		}
		if (chat != null && inside(callButton, x, y)) {
			Overlay.ActiveCall call = service.overlay().active();
			if (call != null && call.chatId == chat.id()) service.hangUp();
			else if (call == null) service.startCall(chat.id(), this::showNotice);
			else showNotice("Hang up your other call first.");
			return true;
		}
		if (inside(inputBox, x, y) && !input.isEmpty()) {
			// Put the cursor where the click landed.
			int target = inputScroll;
			while (target < input.length()
					&& inputTextX + widthOf(input.substring(inputScroll, target + 1)) <= x + 2) {
				target++;
			}
			cursor = target;
		}
		return true;
	}

	public boolean mouseScrolled(double x, double y, double amount) {
		if (inside(listBox, x, y)) {
			listScroll -= (int) Math.round(amount * ROW);
			return true;
		}
		if (panelBox != null && inside(panelBox, x, y)) {
			messageScroll += (int) Math.round(amount * 20);
			return true;
		}
		return false;
	}

	/** A key press. Returns true when used; Escape is left to the screen, which closes. */
	public boolean keyPressed(int key, int modifiers) {
		boolean control = (modifiers & MOD_CONTROL) != 0;
		boolean alt = (modifiers & MOD_ALT) != 0;
		switch (key) {
			case KEY_ENTER, KEY_KP_ENTER -> send();
			case KEY_BACKSPACE -> {
				if (cursor > 0) {
					int from = control ? wordStart(cursor) : previous(cursor);
					input = input.substring(0, from) + input.substring(cursor);
					cursor = from;
				}
			}
			case KEY_DELETE -> {
				if (cursor < input.length()) input = input.substring(0, cursor) + input.substring(next(cursor));
			}
			case KEY_LEFT -> cursor = control ? wordStart(cursor) : previous(cursor);
			case KEY_RIGHT -> cursor = control ? wordEnd(cursor) : next(cursor);
			case KEY_HOME -> cursor = 0;
			case KEY_END -> cursor = input.length();
			case KEY_PAGE_UP -> messageScroll += 60;
			case KEY_PAGE_DOWN -> messageScroll = Math.max(0, messageScroll - 60);
			case KEY_UP, KEY_DOWN -> {
				if (!alt) return true;
				moveSelection(key == KEY_UP ? -1 : 1);
			}
			case KEY_V -> {
				if (!control) return false; // typed through charTyped
				String pasted = clipboard.get();
				if (pasted != null) insert(pasted.replace("\r", "").replace('\n', ' ').replace('\t', ' '));
			}
			default -> {
				return false;
			}
		}
		return true;
	}

	/** Typed text (one character, or a surrogate pair). */
	public boolean charTyped(String text) {
		if (text == null || text.isEmpty()) return false;
		for (int i = 0; i < text.length(); i++) {
			if (Character.isISOControl(text.charAt(i))) return false;
		}
		insert(text);
		return true;
	}

	private void insert(String text) {
		if (currentChat() == null || text.isEmpty()) return;
		int room = MAX_LENGTH - input.length();
		if (room <= 0) return;
		if (text.length() > room) text = text.substring(0, room);
		input = input.substring(0, cursor) + text + input.substring(cursor);
		cursor += text.length();
	}

	private void send() {
		SocialTapService.ChatInfo chat = currentChat();
		String text = input.strip();
		if (chat == null || text.isEmpty() || sending) return;
		sending = true;
		input = "";
		cursor = 0;
		inputScroll = 0;
		messageScroll = 0;
		service.sendFromPanel(chat.id(), text, error -> {
			showNotice(error);
			unsent = text;
			sending = false;
		}, () -> sending = false);
	}

	/** Any thread. */
	private void showNotice(String text) {
		noticeUntilMs = System.currentTimeMillis() + 6000;
		notice = text == null ? "" : text;
	}

	private void select(long chatId) {
		if (chatId == service.viewedChat()) return;
		service.view(chatId);
		messageScroll = 0;
		rowsFor = null;
		notice = "";
	}

	private void moveSelection(int step) {
		List<SocialTapService.ChatInfo> chats = service.chats();
		if (chats.isEmpty()) return;
		int index = 0;
		for (int i = 0; i < chats.size(); i++) {
			if (chats.get(i).id() == service.viewedChat()) index = i;
		}
		select(chats.get(Math.floorMod(index + step, chats.size())).id());
	}

	private SocialTapService.ChatInfo currentChat() {
		long open = service.viewedChat();
		for (SocialTapService.ChatInfo chat : service.chats()) {
			if (chat.id() == open) return chat;
		}
		return null;
	}

	// ---- text helpers ----

	private int previous(int at) {
		if (at <= 0) return 0;
		return at >= 2 && Character.isSurrogatePair(input.charAt(at - 2), input.charAt(at - 1)) ? at - 2 : at - 1;
	}

	private int next(int at) {
		if (at >= input.length()) return input.length();
		return at + 1 < input.length() && Character.isSurrogatePair(input.charAt(at), input.charAt(at + 1)) ? at + 2 : at + 1;
	}

	private int wordStart(int at) {
		int i = at;
		while (i > 0 && input.charAt(i - 1) == ' ') i--;
		while (i > 0 && input.charAt(i - 1) != ' ') i--;
		return i;
	}

	private int wordEnd(int at) {
		int i = at;
		while (i < input.length() && input.charAt(i) == ' ') i++;
		while (i < input.length() && input.charAt(i) != ' ') i++;
		return i;
	}

	/** Text width for clicks, which arrive between frames. Measuring only uses the game's font. */
	private int widthOf(String text) {
		Overlay.Canvas canvas = lastCanvas;
		return canvas == null ? text.length() * 6 : canvas.textWidth(text);
	}

	private static String ellipsize(Overlay.Canvas canvas, String text, int width, float scale) {
		if (text == null) return "";
		if (canvas.textWidth(text) * scale <= width) return text;
		String dots = "...";
		int end = text.length();
		while (end > 0 && canvas.textWidth(text.substring(0, end) + dots) * scale > width) end--;
		return end <= 0 ? "" : text.substring(0, end) + dots;
	}

	private static List<String> wrap(Overlay.Canvas canvas, String text, int width) {
		List<String> lines = new ArrayList<>();
		for (String paragraph : text.replace("\r", "").split("\n", -1)) {
			String line = "";
			for (String word : paragraph.split(" ", -1)) {
				String candidate = line.isEmpty() ? word : line + " " + word;
				if (canvas.textWidth(candidate) <= width) {
					line = candidate;
					continue;
				}
				if (!line.isEmpty()) lines.add(line);
				while (canvas.textWidth(word) > width && word.length() > 1) {
					int cut = word.length() - 1;
					while (cut > 1 && canvas.textWidth(word.substring(0, cut)) > width) cut--;
					lines.add(word.substring(0, cut));
					word = word.substring(cut);
				}
				line = word;
			}
			lines.add(line);
		}
		return lines;
	}

	private static void centered(Overlay.Canvas canvas, String text, float centerX, float y, int color) {
		canvas.text(text, centerX - canvas.textWidth(text) / 2f, y, 1f, color);
	}

	private static int brighter(int argb) {
		int r = Math.min(255, ((argb >> 16) & 0xFF) + 24);
		int g = Math.min(255, ((argb >> 8) & 0xFF) + 24);
		int b = Math.min(255, (argb & 0xFF) + 24);
		return (argb & 0xFF000000) | r << 16 | g << 8 | b;
	}

	private static boolean inside(int[] box, double x, double y) {
		return box != null && x >= box[0] && x < box[2] && y >= box[1] && y < box[3];
	}
}
