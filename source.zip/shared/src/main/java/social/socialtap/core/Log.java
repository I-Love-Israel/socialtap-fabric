package social.socialtap.core;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class Log {
	public static final Logger LOG = LoggerFactory.getLogger("SocialTap");

	private Log() {
	}
}
