package social.socialtap.core;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedDeque;

/**
 * What is on screen: the incoming-call box, message popups and the on-call pill. Drawing and
 * clicks are shared by every Minecraft version through {@link Canvas}; all coordinates are GUI
 * pixels. Rendering and clicks happen on the client thread; the service thread only swaps state.
 */
public final class Overlay {
	/** Version-specific drawing. Colours are ARGB and everything drawn here is fully opaque. */
	public interface Canvas {
		int width();

		int height();

		void fill(int x1, int y1, int x2, int y2, int argb);

		/** Draws text with its top-left corner at (x, y), scaled about that corner. */
		void text(String text, float x, float y, float scale, int argb);

		int textWidth(String text);
	}

	public interface Actions {
		void respond(IncomingCall call);

		void decline(IncomingCall call);

		void hangUp();
	}

	public record IncomingCall(String callId, long chatId, String username, long atMs, int relayRate, int frameSamples,
			int frameBytes) {
	}

	public static final class ActiveCall {
		public final String callId;
		public final long chatId;
		public final String username;
		public volatile boolean connected;
		public volatile long connectedAtMs;

		public ActiveCall(String callId, long chatId, String username) {
			this.callId = callId;
			this.chatId = chatId;
			this.username = username;
		}
	}

	public record Popup(String title, String body, Runnable onClick, long durationMs) {
	}

	private static final int BACKGROUND = 0xFF14141C;
	private static final int BORDER = 0xFF6C5CE7;
	private static final int WHITE = 0xFFFFFFFF;
	private static final int MUTED = 0xFFA0A0B4;
	private static final int GREEN = 0xFF1FB954;
	private static final int GREEN_DARK = 0xFF168A3E;
	private static final int RED = 0xFFD63031;
	private static final int FONT_HEIGHT = 9;
	private static final int MAX_QUEUED_POPUPS = 5;
	private static final int CARD_MARGIN = 4;
	private static final int CARD_WIDTH = 176;

	private final ConcurrentLinkedDeque<Popup> popups = new ConcurrentLinkedDeque<>();
	private volatile IncomingCall incoming;
	private volatile ActiveCall active;
	private volatile Actions actions;
	private volatile boolean obnoxious = true;
	private Popup current;
	private long currentSinceMs;

	// Hit boxes from the last frame: {x1, y1, x2, y2}, or null when not drawn.
	private int[] callBox;
	private int[] closeBox;
	private int[] popupBox;
	private int[] pillBox;
	private int[] answerBox;
	private int[] declineBox;

	public void setActions(Actions actions) {
		this.actions = actions;
	}

	/**
	 * Obnoxious: everything lands in the middle of the screen and any click acts on it. Otherwise
	 * calls and messages are small cards in the top-left corner that stay out of the way.
	 */
	public void setObnoxious(boolean obnoxious) {
		this.obnoxious = obnoxious;
	}

	/** Picks up the ringing call, if there is one. */
	public boolean answer() {
		IncomingCall ringing = incoming;
		if (ringing == null) return false;
		respond(ringing);
		return true;
	}

	/** Turns the ringing call down, if there is one. */
	public boolean decline() {
		IncomingCall ringing = incoming;
		if (ringing == null) return false;
		decline(ringing);
		return true;
	}

	public IncomingCall incoming() {
		return incoming;
	}

	public void setIncoming(IncomingCall call) {
		incoming = call;
	}

	public ActiveCall active() {
		return active;
	}

	public void setActive(ActiveCall call) {
		active = call;
	}

	public void show(Popup popup) {
		popups.addLast(popup);
		while (popups.size() > MAX_QUEUED_POPUPS) popups.pollFirst();
	}

	/** True while something is covering the middle of the screen. */
	public boolean blocking() {
		return incoming != null || current != null || !popups.isEmpty();
	}

	// ---- drawing ----

	public void render(Canvas canvas) {
		long now = System.currentTimeMillis();
		callBox = closeBox = popupBox = pillBox = answerBox = declineBox = null;
		boolean loud = obnoxious;

		IncomingCall ringing = incoming;
		if (ringing != null && loud) {
			// A popup hidden behind the call box gets its full time once the call is dealt with.
			currentSinceMs = now;
		} else {
			if (current != null && now - currentSinceMs >= current.durationMs()) current = null;
			if (current == null) {
				current = popups.pollFirst();
				currentSinceMs = now;
			}
		}

		ActiveCall call = active;
		int top = CARD_MARGIN;
		if (call != null) top = renderPill(canvas, call, now) + CARD_MARGIN;

		if (loud) {
			if (ringing != null) {
				renderCall(canvas, ringing, now);
			} else if (current != null) {
				renderPopup(canvas, current, now);
			}
		} else {
			if (ringing != null) top = renderCallCard(canvas, ringing, top) + CARD_MARGIN;
			if (current != null) renderPopupCard(canvas, current, now, top);
		}
	}

	/** The quiet incoming call: a small card in the top-left corner with ordinary buttons. */
	private int renderCallCard(Canvas canvas, IncomingCall call, int top) {
		int boxWidth = Math.min(canvas.width() - 2 * CARD_MARGIN, CARD_WIDTH);
		int inner = boxWidth - 12;
		float nameScale = fit(canvas, call.username(), inner, 1.5f);
		int nameHeight = (int) Math.ceil(FONT_HEIGHT * nameScale);
		int x1 = CARD_MARGIN;
		int x2 = x1 + boxWidth;
		int y2 = top + 6 + FONT_HEIGHT + 2 + nameHeight + 4 + 14 + 3 + 7 + 5;
		panel(canvas, x1, top, x2, y2, 1);

		int y = top + 6;
		canvas.text("Incoming call", x1 + 6, y, 1f, MUTED);
		y += FONT_HEIGHT + 2;
		canvas.text(call.username(), x1 + 6, y, nameScale, WHITE);
		y += nameHeight + 4;

		int middle = (x1 + x2) / 2;
		canvas.fill(x1 + 6, y, middle - 2, y + 14, GREEN_DARK);
		centered(canvas, "Answer", (x1 + 6 + middle - 2) / 2f, y + 3, 1f, WHITE);
		answerBox = new int[] {x1 + 6, y, middle - 2, y + 14};
		canvas.fill(middle + 2, y, x2 - 6, y + 14, RED);
		centered(canvas, "Decline", (middle + 2 + x2 - 6) / 2f, y + 3, 1f, WHITE);
		declineBox = new int[] {middle + 2, y, x2 - 6, y + 14};
		y += 14 + 3;

		String hint = "Type /socialtap answer or decline";
		canvas.text(hint, x1 + 6, y, fit(canvas, hint, inner, 0.75f), MUTED);
		return y2;
	}

	/** The quiet message: a small card in the top-left corner. Clicking it does nothing. */
	private void renderPopupCard(Canvas canvas, Popup popup, long now, int top) {
		int boxWidth = Math.min(canvas.width() - 2 * CARD_MARGIN, CARD_WIDTH);
		int inner = boxWidth - 12;
		List<String> lines = wrap(canvas, popup.body(), inner, 3);
		int x1 = CARD_MARGIN;
		int x2 = x1 + boxWidth;
		int y2 = top + 5 + FONT_HEIGHT + 2 + lines.size() * (FONT_HEIGHT + 1) + 6;
		panel(canvas, x1, top, x2, y2, 1);

		int y = top + 5;
		canvas.text(popup.title(), x1 + 6, y, fit(canvas, popup.title(), inner, 1f), BORDER);
		y += FONT_HEIGHT + 2;
		for (String line : lines) {
			canvas.text(line, x1 + 6, y, 1f, WHITE);
			y += FONT_HEIGHT + 1;
		}

		float left = 1f - Math.min(1f, (now - currentSinceMs) / (float) popup.durationMs());
		canvas.fill(x1 + 1, y2 - 3, x1 + 1 + (int) ((boxWidth - 2) * left), y2 - 1, BORDER);
	}

	private void renderCall(Canvas canvas, IncomingCall call, long now) {
		int width = canvas.width();
		int height = canvas.height();
		int boxWidth = Math.max(200, width * 4 / 5);
		int boxHeight = Math.max(140, height * 4 / 5);
		int x1 = (width - boxWidth) / 2;
		int y1 = (height - boxHeight) / 2;
		int x2 = x1 + boxWidth;
		int y2 = y1 + boxHeight;
		panel(canvas, x1, y1, x2, y2);
		callBox = new int[] {x1, y1, x2, y2};

		centered(canvas, "SOCIAL TAP", width / 2f, y1 + 8, 1f, BORDER);
		centered(canvas, "Incoming call", width / 2f, y1 + 22, 1.5f, MUTED);
		float nameScale = fit(canvas, call.username(), boxWidth - 40, 3f);
		centered(canvas, call.username(), width / 2f, y1 + 42, nameScale, WHITE);

		// The one big button.
		int buttonTop = y1 + 42 + (int) (FONT_HEIGHT * nameScale) + 10;
		int bx1 = x1 + 12;
		int bx2 = x2 - 12;
		int by2 = y2 - 12;
		boolean pulse = (now / 400) % 2 == 0;
		canvas.fill(bx1, buttonTop, bx2, by2, pulse ? GREEN : GREEN_DARK);
		float labelScale = fit(canvas, "RESPOND", bx2 - bx1 - 30, Math.max(2f, (by2 - buttonTop) / 22f));
		centered(canvas, "RESPOND", width / 2f, (buttonTop + by2) / 2f - FONT_HEIGHT * labelScale / 2f + 1, labelScale, WHITE);

		// The very small X, mobile-ad style.
		int cx2 = x2 - 3;
		int cy1 = y1 + 3;
		canvas.fill(cx2 - 6, cy1, cx2, cy1 + 6, 0xFF2A2A36);
		canvas.text("x", cx2 - 4.5f, cy1 + 0.5f, 0.5f, MUTED);
		closeBox = new int[] {cx2 - 6, cy1, cx2, cy1 + 6};
	}

	private void renderPopup(Canvas canvas, Popup popup, long now) {
		int width = canvas.width();
		int height = canvas.height();
		int boxWidth = Math.min(width - 20, Math.max(180, width * 3 / 5));
		int textWidth = boxWidth - 20;
		List<String> lines = wrap(canvas, popup.body(), textWidth, 8);
		float titleScale = fit(canvas, popup.title(), textWidth, 1.5f);
		int titleHeight = (int) Math.ceil(FONT_HEIGHT * titleScale) + 4;
		int hintHeight = popup.onClick() == null ? 0 : FONT_HEIGHT + 3;
		int boxHeight = 10 + titleHeight + lines.size() * (FONT_HEIGHT + 1) + hintHeight + 12;
		int x1 = (width - boxWidth) / 2;
		int y1 = (height - boxHeight) / 2;
		int x2 = x1 + boxWidth;
		int y2 = y1 + boxHeight;
		panel(canvas, x1, y1, x2, y2);
		popupBox = new int[] {x1, y1, x2, y2};

		int y = y1 + 10;
		canvas.text(popup.title(), x1 + 10, y, titleScale, BORDER);
		y += titleHeight;
		for (String line : lines) {
			canvas.text(line, x1 + 10, y, 1f, WHITE);
			y += FONT_HEIGHT + 1;
		}
		if (popup.onClick() != null) canvas.text("Click to open in Social Tap", x1 + 10, y + 3, 1f, MUTED);

		// Time left, draining along the bottom edge.
		float left = 1f - Math.min(1f, (now - currentSinceMs) / (float) popup.durationMs());
		canvas.fill(x1 + 2, y2 - 5, x1 + 2 + (int) ((boxWidth - 4) * left), y2 - 2, BORDER);
	}

	/** Returns the bottom edge, so the quiet cards can sit below it. */
	private int renderPill(Canvas canvas, ActiveCall call, long now) {
		String label;
		if (call.connected) {
			long seconds = Math.max(0, (now - call.connectedAtMs) / 1000);
			label = "On call with " + call.username + "  " + String.format("%d:%02d", seconds / 60, seconds % 60);
		} else {
			label = "Connecting call with " + call.username + "...";
		}
		String hint = "Hang up: /socialtap hangup, or open a menu and click here";
		int boxWidth = Math.max(canvas.textWidth(label), canvas.textWidth(hint) / 2) + 16;
		int x1 = (canvas.width() - boxWidth) / 2;
		int x2 = x1 + boxWidth;
		int y1 = 3;
		int y2 = y1 + FONT_HEIGHT + 13;
		canvas.fill(x1, y1, x2, y2, call.connected ? GREEN_DARK : 0xFF2A2A36);
		canvas.fill(x1, y2 - 1, x2, y2, RED);
		centered(canvas, label, canvas.width() / 2f, y1 + 3, 1f, WHITE);
		centered(canvas, hint, canvas.width() / 2f, y1 + 3 + FONT_HEIGHT + 2, 0.5f, 0xFFE0E0E0);
		pillBox = new int[] {x1, y1, x2, y2};
		return y2;
	}

	private static void panel(Canvas canvas, int x1, int y1, int x2, int y2) {
		panel(canvas, x1, y1, x2, y2, 2);
	}

	private static void panel(Canvas canvas, int x1, int y1, int x2, int y2, int border) {
		canvas.fill(x1, y1, x2, y2, BORDER);
		canvas.fill(x1 + border, y1 + border, x2 - border, y2 - border, BACKGROUND);
	}

	private static void centered(Canvas canvas, String text, float centerX, float y, float scale, int argb) {
		canvas.text(text, centerX - canvas.textWidth(text) * scale / 2f, y, scale, argb);
	}

	/** The largest scale up to {@code max} at which the text fits the width. */
	private static float fit(Canvas canvas, String text, int width, float max) {
		int natural = Math.max(1, canvas.textWidth(text));
		return Math.max(0.5f, Math.min(max, width / (float) natural));
	}

	private static List<String> wrap(Canvas canvas, String text, int width, int maxLines) {
		List<String> lines = new ArrayList<>();
		for (String paragraph : text.replace("\r", "").split("\n")) {
			String line = "";
			for (String word : paragraph.split(" ")) {
				String candidate = line.isEmpty() ? word : line + " " + word;
				if (canvas.textWidth(candidate) <= width) {
					line = candidate;
					continue;
				}
				if (!line.isEmpty()) lines.add(line);
				// Break a word that is wider than the box on its own.
				while (canvas.textWidth(word) > width && word.length() > 1) {
					int cut = word.length() - 1;
					while (cut > 1 && canvas.textWidth(word.substring(0, cut)) > width) cut--;
					lines.add(word.substring(0, cut));
					word = word.substring(cut);
				}
				line = word;
			}
			lines.add(line);
		}
		if (lines.size() > maxLines) {
			lines = new ArrayList<>(lines.subList(0, maxLines));
			lines.set(maxLines - 1, lines.get(maxLines - 1) + "...");
		}
		return lines;
	}

	// ---- clicks ----

	/** A click while a menu is open and the cursor is free. Returns true when it was used. */
	public boolean screenClick(double x, double y) {
		Actions handler = actions;
		IncomingCall ringing = incoming;
		if (ringing != null && inside(answerBox, x, y)) {
			respond(ringing);
			return true;
		}
		if (ringing != null && inside(declineBox, x, y)) {
			decline(ringing);
			return true;
		}
		if (ringing != null && callBox != null) {
			if (inside(closeBox, x, y)) {
				decline(ringing);
				return true;
			}
			if (inside(callBox, x, y)) {
				respond(ringing);
				return true;
			}
			return false;
		}
		if (current != null && inside(popupBox, x, y)) {
			openCurrent();
			return true;
		}
		if (active != null && inside(pillBox, x, y)) {
			if (handler != null) handler.hangUp();
			return true;
		}
		return false;
	}

	/**
	 * A new attack click in the world, where the crosshair sits on whatever is in the middle of
	 * the screen. Picks up a ringing call, otherwise opens the popup. Returns true when used.
	 * The quiet cards are out of the way in the corner, so they never take a click in the world.
	 */
	public boolean attackClick() {
		if (!obnoxious) return false;
		IncomingCall ringing = incoming;
		if (ringing != null) {
			respond(ringing);
			return true;
		}
		if (current != null) {
			openCurrent();
			return true;
		}
		return false;
	}

	private void respond(IncomingCall ringing) {
		incoming = null;
		Actions handler = actions;
		if (handler != null) handler.respond(ringing);
	}

	private void decline(IncomingCall ringing) {
		incoming = null;
		Actions handler = actions;
		if (handler != null) handler.decline(ringing);
	}

	private void openCurrent() {
		Popup popup = current;
		current = null;
		if (popup != null && popup.onClick() != null) popup.onClick().run();
	}

	private static boolean inside(int[] box, double x, double y) {
		return box != null && x >= box[0] && x < box[2] && y >= box[1] && y < box[3];
	}
}
