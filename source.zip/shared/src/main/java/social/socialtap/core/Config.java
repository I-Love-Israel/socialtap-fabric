package social.socialtap.core;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.annotations.SerializedName;

/** config/socialtap.json. Holds the login (refresh token), so treat the file as private. */
public final class Config {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

	@SerializedName("client_id")
	public String clientId = "";
	@SerializedName("refresh_token")
	public String refreshToken = "";
	/** /socialtap obnoxious true|false. Off: small cards in the top-left corner that ignore clicks. */
	@SerializedName("obnoxious")
	public volatile boolean obnoxious = true;
	@SerializedName("message_seconds")
	public int messageSeconds = 10;
	@SerializedName("quiet_message_seconds")
	public int quietMessageSeconds = 5;
	@SerializedName("show_global_chat")
	public boolean showGlobalChat = false;
	@SerializedName("ringtone")
	public boolean ringtone = true;
	/** /socialtap activity true|false. Shows what you are playing as a card on your Social Tap profile. */
	@SerializedName("activity_status")
	public volatile boolean activityStatus = true;
	/** Who sees the card: "friends", or "all" for every signed-in Social Tap user. */
	@SerializedName("activity_visibility")
	public String activityVisibility = "friends";
	/** A public HTTPS image for the card. Empty uses the built-in grass block. */
	@SerializedName("activity_background")
	public String activityBackground = "";

	private transient Path file;

	public static Config load(Path file) {
		Config config = null;
		try {
			if (Files.exists(file)) {
				config = GSON.fromJson(Files.readString(file, StandardCharsets.UTF_8), Config.class);
			}
		} catch (Exception e) {
			Log.LOG.warn("Could not read {}: {}", file, e.toString());
		}
		if (config == null) config = new Config();
		if (config.clientId == null) config.clientId = "";
		if (config.refreshToken == null) config.refreshToken = "";
		if (config.messageSeconds <= 0) config.messageSeconds = 10;
		if (config.quietMessageSeconds <= 0) config.quietMessageSeconds = 5;
		if (!"all".equals(config.activityVisibility)) config.activityVisibility = "friends";
		if (config.activityBackground == null) config.activityBackground = "";
		config.file = file;
		if (!Files.exists(file)) config.save();
		return config;
	}

	public synchronized void save() {
		try {
			Files.createDirectories(file.getParent());
			Files.writeString(file, GSON.toJson(this), StandardCharsets.UTF_8);
		} catch (IOException e) {
			Log.LOG.warn("Could not save {}: {}", file, e.toString());
		}
	}

	public String effectiveActivityBackground() {
		String custom = activityBackground.trim();
		return custom.startsWith("https://") ? custom : Constants.ACTIVITY_BACKGROUND;
	}

	/** The hardcoded client ID, or the one from the config file while the placeholder is in place. */
	public String effectiveClientId() {
		String hardcoded = Constants.CLIENT_ID;
		if (!hardcoded.isBlank() && !hardcoded.startsWith("PASTE_")) return hardcoded.trim();
		return clientId.trim();
	}
}
