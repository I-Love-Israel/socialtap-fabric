package social.socialtap.core;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.annotations.SerializedName;

/** config/socialtap.json. Holds the login (refresh token), so treat the file as private. */
public final class Config {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

	@SerializedName("client_id")
	public String clientId = "";
	@SerializedName("refresh_token")
	public String refreshToken = "";
	/** /socialtap obnoxious true|false. Off: small cards in the top-left corner that ignore clicks. */
	@SerializedName("obnoxious")
	public volatile boolean obnoxious = true;
	@SerializedName("message_seconds")
	public int messageSeconds = 10;
	@SerializedName("quiet_message_seconds")
	public int quietMessageSeconds = 5;
	@SerializedName("show_global_chat")
	public boolean showGlobalChat = false;
	@SerializedName("ringtone")
	public boolean ringtone = true;

	private transient Path file;

	public static Config load(Path file) {
		Config config = null;
		try {
			if (Files.exists(file)) {
				config = GSON.fromJson(Files.readString(file, StandardCharsets.UTF_8), Config.class);
			}
		} catch (Exception e) {
			Log.LOG.warn("Could not read {}: {}", file, e.toString());
		}
		if (config == null) config = new Config();
		if (config.clientId == null) config.clientId = "";
		if (config.refreshToken == null) config.refreshToken = "";
		if (config.messageSeconds <= 0) config.messageSeconds = 10;
		if (config.quietMessageSeconds <= 0) config.quietMessageSeconds = 5;
		config.file = file;
		if (!Files.exists(file)) config.save();
		return config;
	}

	public synchronized void save() {
		try {
			Files.createDirectories(file.getParent());
			Files.writeString(file, GSON.toJson(this), StandardCharsets.UTF_8);
		} catch (IOException e) {
			Log.LOG.warn("Could not save {}: {}", file, e.toString());
		}
	}

	/** The hardcoded client ID, or the one from the config file while the placeholder is in place. */
	public String effectiveClientId() {
		String hardcoded = Constants.CLIENT_ID;
		if (!hardcoded.isBlank() && !hardcoded.startsWith("PASTE_")) return hardcoded.trim();
		return clientId.trim();
	}
}
