package social.socialtap.core;

import java.io.ByteArrayOutputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.WebSocket;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/**
 * A small Socket.IO 4 client (Engine.IO 4, WebSocket transport only, default namespace) on the
 * JDK's own WebSocket. It covers what Social Tap uses: events, acknowledgements and binary
 * attachments. One instance is one connection; make a new one to reconnect.
 */
public final class SocketIo implements WebSocket.Listener {
	public interface EventHandler {
		void handle(JsonElement data, List<byte[]> attachments);
	}

	private static final Gson GSON = new Gson();

	private final ScheduledExecutorService scheduler;
	private final ExecutorService sendQueue = Executors.newSingleThreadExecutor(runnable -> {
		Thread thread = new Thread(runnable, "SocialTap-socket-send");
		thread.setDaemon(true);
		return thread;
	});
	private final Map<String, EventHandler> handlers = new ConcurrentHashMap<>();
	private final Map<Integer, Consumer<JsonObject>> acks = new ConcurrentHashMap<>();
	private final AtomicInteger nextAckId = new AtomicInteger();
	private final AtomicBoolean closed = new AtomicBoolean();
	private final StringBuilder textBuffer = new StringBuilder();
	private final ByteArrayOutputStream binaryBuffer = new ByteArrayOutputStream();

	private volatile WebSocket webSocket;
	private volatile boolean connected;
	private volatile String sid = "";
	private volatile long lastActivityMs = System.currentTimeMillis();
	private volatile long heartbeatMs = 45_000;
	private JsonObject auth;
	private Runnable onConnect = () -> { };
	private Consumer<String> onDisconnect = reason -> { };

	// A binary event whose attachments are still arriving.
	private int pendingType;
	private int pendingAckId;
	private JsonArray pendingPayload;
	private int pendingRemaining;
	private final List<byte[]> pendingAttachments = new ArrayList<>();

	public SocketIo(ScheduledExecutorService scheduler) {
		this.scheduler = scheduler;
	}

	public void on(String event, EventHandler handler) {
		handlers.put(event, handler);
	}

	public void onConnect(Runnable callback) {
		this.onConnect = callback;
	}

	public void onDisconnect(Consumer<String> callback) {
		this.onDisconnect = callback;
	}

	public boolean connected() {
		return connected && !closed.get();
	}

	public boolean closed() {
		return closed.get();
	}

	public String sid() {
		return sid;
	}

	/** True when the server has been silent for longer than its own heartbeat allows. */
	public boolean stale() {
		return System.currentTimeMillis() - lastActivityMs > heartbeatMs + 10_000;
	}

	public void connect(HttpClient http, String baseUrl, JsonObject auth) {
		this.auth = auth;
		String url = baseUrl.replaceFirst("^http", "ws") + "/socket.io/?EIO=4&transport=websocket";
		http.newWebSocketBuilder()
				.header("User-Agent", Constants.USER_AGENT)
				.connectTimeout(java.time.Duration.ofSeconds(15))
				.buildAsync(URI.create(url), this)
				.whenComplete((socket, error) -> {
					if (error != null) {
						fail("could not connect: " + rootMessage(error));
					} else if (closed.get()) {
						socket.abort();
					}
				});
	}

	/** Sends an event and reports the acknowledgement envelope ({"status":…,"data":…}). */
	public void emit(String event, JsonObject data, Consumer<JsonObject> ack) {
		if (!connected()) {
			if (ack != null) ack.accept(localError("not connected"));
			return;
		}
		StringBuilder packet = new StringBuilder("42");
		if (ack != null) {
			int id = nextAckId.getAndIncrement();
			acks.put(id, ack);
			packet.append(id);
			scheduler.schedule(() -> {
				Consumer<JsonObject> waiting = acks.remove(id);
				if (waiting != null) waiting.accept(localError("no reply from Social Tap"));
			}, 15, TimeUnit.SECONDS);
		}
		packet.append('[').append(GSON.toJson(event)).append(',').append(GSON.toJson(data)).append(']');
		sendText(packet.toString());
	}

	/** Sends an event with one binary attachment stored under {@code key} in {@code data}. */
	public void emitBinary(String event, JsonObject data, String key, byte[] bytes) {
		if (!connected()) return;
		JsonObject placeholder = new JsonObject();
		placeholder.addProperty("_placeholder", true);
		placeholder.addProperty("num", 0);
		data.add(key, placeholder);
		String header = "451-[" + GSON.toJson(event) + "," + GSON.toJson(data) + "]";
		WebSocket socket = webSocket;
		if (socket == null) return;
		sendQueue.execute(() -> {
			try {
				// Text header then the attachment, back to back: the queue keeps them adjacent.
				socket.sendText(header, true).get(10, TimeUnit.SECONDS);
				socket.sendBinary(ByteBuffer.wrap(bytes), true).get(10, TimeUnit.SECONDS);
			} catch (Exception e) {
				fail("send failed: " + rootMessage(e));
			}
		});
	}

	public void close() {
		if (!closed.compareAndSet(false, true)) return;
		connected = false;
		WebSocket socket = webSocket;
		if (socket != null) socket.abort();
		sendQueue.shutdownNow();
		failPendingAcks();
	}

	private void fail(String reason) {
		if (closed.get()) return;
		close();
		onDisconnect.accept(reason);
	}

	private void failPendingAcks() {
		for (Integer id : new ArrayList<>(acks.keySet())) {
			Consumer<JsonObject> waiting = acks.remove(id);
			if (waiting != null) waiting.accept(localError("disconnected"));
		}
	}

	private void sendText(String text) {
		WebSocket socket = webSocket;
		if (socket == null || closed.get()) return;
		try {
			sendQueue.execute(() -> {
				try {
					socket.sendText(text, true).get(10, TimeUnit.SECONDS);
				} catch (Exception e) {
					fail("send failed: " + rootMessage(e));
				}
			});
		} catch (RuntimeException rejected) {
			// The queue was shut down by close(): nothing left to send to.
		}
	}

	private static JsonObject localError(String message) {
		JsonObject envelope = new JsonObject();
		envelope.addProperty("status", 0);
		envelope.addProperty("error", message);
		return envelope;
	}

	/** The error text of an acknowledgement, wherever the server put it. */
	public static String errorOf(JsonObject envelope) {
		if (envelope.has("error") && envelope.get("error").isJsonPrimitive()) return envelope.get("error").getAsString();
		if (envelope.has("data") && envelope.get("data").isJsonObject()) {
			JsonObject data = envelope.getAsJsonObject("data");
			if (data.has("error") && data.get("error").isJsonPrimitive()) return data.get("error").getAsString();
		}
		return "status " + statusOf(envelope);
	}

	public static int statusOf(JsonObject envelope) {
		try {
			return envelope.get("status").getAsInt();
		} catch (Exception e) {
			return 0;
		}
	}

	// ---- WebSocket.Listener: calls arrive one at a time, in order ----

	@Override
	public void onOpen(WebSocket socket) {
		webSocket = socket;
		lastActivityMs = System.currentTimeMillis();
		socket.request(1);
	}

	@Override
	public CompletionStage<?> onText(WebSocket socket, CharSequence data, boolean last) {
		textBuffer.append(data);
		if (last) {
			String packet = textBuffer.toString();
			textBuffer.setLength(0);
			try {
				handlePacket(packet);
			} catch (Exception e) {
				Log.LOG.warn("Bad Social Tap packet: {}", e.toString());
			}
		}
		socket.request(1);
		return null;
	}

	@Override
	public CompletionStage<?> onBinary(WebSocket socket, ByteBuffer data, boolean last) {
		byte[] chunk = new byte[data.remaining()];
		data.get(chunk);
		binaryBuffer.write(chunk, 0, chunk.length);
		if (last) {
			byte[] attachment = binaryBuffer.toByteArray();
			binaryBuffer.reset();
			try {
				handleAttachment(attachment);
			} catch (Exception e) {
				Log.LOG.warn("Bad Social Tap attachment: {}", e.toString());
			}
		}
		socket.request(1);
		return null;
	}

	@Override
	public CompletionStage<?> onClose(WebSocket socket, int statusCode, String reason) {
		fail("closed by server" + (reason == null || reason.isEmpty() ? "" : ": " + reason));
		return null;
	}

	@Override
	public void onError(WebSocket socket, Throwable error) {
		fail(rootMessage(error));
	}

	// ---- Engine.IO / Socket.IO framing ----

	private void handlePacket(String packet) {
		lastActivityMs = System.currentTimeMillis();
		if (packet.isEmpty()) return;
		switch (packet.charAt(0)) {
			case '0' -> { // Engine.IO open: join the default namespace with our auth.
				JsonObject open = JsonParser.parseString(packet.substring(1)).getAsJsonObject();
				long interval = open.has("pingInterval") ? open.get("pingInterval").getAsLong() : 25_000;
				long timeout = open.has("pingTimeout") ? open.get("pingTimeout").getAsLong() : 20_000;
				heartbeatMs = interval + timeout;
				sendText("40" + GSON.toJson(auth));
			}
			case '1' -> fail("closed by server");
			case '2' -> sendText("3"); // ping -> pong
			case '4' -> handleMessage(packet);
			default -> { }
		}
	}

	private void handleMessage(String packet) {
		if (packet.length() < 2) return;
		int type = packet.charAt(1) - '0';
		int index = 2;
		int attachments = 0;
		if (type == 5 || type == 6) {
			int dash = packet.indexOf('-', index);
			attachments = Integer.parseInt(packet.substring(index, dash));
			index = dash + 1;
		}
		if (index < packet.length() && packet.charAt(index) == '/') {
			int comma = packet.indexOf(',', index);
			index = comma < 0 ? packet.length() : comma + 1;
		}
		int idStart = index;
		while (index < packet.length() && Character.isDigit(packet.charAt(index))) index++;
		int ackId = index > idStart ? Integer.parseInt(packet.substring(idStart, index)) : -1;
		String json = packet.substring(index);
		JsonElement payload = json.isEmpty() ? JsonNull.INSTANCE : JsonParser.parseString(json);

		switch (type) {
			case 0 -> { // connected to the namespace
				if (payload.isJsonObject() && payload.getAsJsonObject().has("sid")) {
					sid = payload.getAsJsonObject().get("sid").getAsString();
				}
				connected = true;
				onConnect.run();
			}
			case 1 -> fail("disconnected by server");
			case 4 -> { // connect refused (bad token, banned, ineligible)
				String message = "refused";
				if (payload.isJsonObject() && payload.getAsJsonObject().has("message")) {
					message = payload.getAsJsonObject().get("message").getAsString();
				}
				fail("connect_error: " + message);
			}
			case 2, 3 -> dispatch(type, ackId, payload.getAsJsonArray(), List.of());
			case 5, 6 -> {
				if (attachments == 0) {
					dispatch(type - 3, ackId, payload.getAsJsonArray(), List.of());
				} else {
					pendingType = type - 3;
					pendingAckId = ackId;
					pendingPayload = payload.getAsJsonArray();
					pendingRemaining = attachments;
					pendingAttachments.clear();
				}
			}
			default -> { }
		}
	}

	private void handleAttachment(byte[] attachment) {
		lastActivityMs = System.currentTimeMillis();
		if (pendingPayload == null) return;
		pendingAttachments.add(attachment);
		if (--pendingRemaining > 0) return;
		JsonArray payload = pendingPayload;
		pendingPayload = null;
		dispatch(pendingType, pendingAckId, payload, new ArrayList<>(pendingAttachments));
		pendingAttachments.clear();
	}

	private void dispatch(int type, int ackId, JsonArray payload, List<byte[]> attachments) {
		if (type == 3) {
			Consumer<JsonObject> waiting = acks.remove(ackId);
			if (waiting == null) return;
			JsonElement first = payload.size() > 0 ? payload.get(0) : JsonNull.INSTANCE;
			waiting.accept(first.isJsonObject() ? first.getAsJsonObject() : localError("unexpected reply"));
			return;
		}
		if (payload.size() == 0) return;
		EventHandler handler = handlers.get(payload.get(0).getAsString());
		if (handler == null) return;
		handler.handle(payload.size() > 1 ? payload.get(1) : JsonNull.INSTANCE, attachments);
	}

	private static String rootMessage(Throwable error) {
		Throwable cause = error;
		while (cause.getCause() != null) cause = cause.getCause();
		return cause.getMessage() == null ? cause.getClass().getSimpleName() : cause.getMessage();
	}
}
