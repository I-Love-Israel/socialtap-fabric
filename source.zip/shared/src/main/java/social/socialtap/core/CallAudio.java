package social.socialtap.core;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.SourceDataLine;
import javax.sound.sampled.TargetDataLine;

/**
 * Voice for one call over Social Tap's server audio relay.
 *
 * <p>The relay carries mono 4-bit IMA ADPCM in independently decodable 50 ms packets: a four-byte
 * (zero) header, then one nibble per sample, low nibble first. The predictor and step index
 * restart at zero in every packet. The call's relay format gives the sample rate and packet size,
 * so the microphone and speakers run at 48 kHz and are resampled to and from that rate.
 */
public final class CallAudio {
	private static final int DEVICE_RATE = 48_000;
	private static final AudioFormat DEVICE_FORMAT = new AudioFormat(DEVICE_RATE, 16, 1, true, false);

	private static final int[] STEPS = {
		7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 19, 21, 23, 25, 28, 31,
		34, 37, 41, 45, 50, 55, 60, 66, 73, 80, 88, 97, 107, 118, 130, 143,
		157, 173, 190, 209, 230, 253, 279, 307, 337, 371, 408, 449, 494, 544,
		598, 658, 724, 796, 876, 963, 1060, 1166, 1282, 1411, 1552, 1707,
		1878, 2066, 2272, 2499, 2749, 3024, 3327, 3660, 4026, 4428, 4871,
		5358, 5894, 6484, 7132, 7845, 8630, 9493, 10442, 11487, 12635,
		13899, 15289, 16818, 18500, 20350, 22385, 24623, 27086, 29794, 32767
	};
	private static final int[] INDEX = {-1, -1, -1, -1, 2, 4, 6, 8};

	private final int relayRate;
	private final int frameSamples;
	private final int frameBytes;
	private final Consumer<byte[]> sender;
	private final ArrayBlockingQueue<short[]> playQueue = new ArrayBlockingQueue<>(8);
	private volatile boolean running;
	private volatile TargetDataLine microphone;
	private volatile SourceDataLine speaker;

	public CallAudio(int relayRate, int frameSamples, int frameBytes, Consumer<byte[]> sender) {
		if (frameSamples < 400 || frameSamples > 1500 || frameSamples % 2 != 0
				|| relayRate != frameSamples * 20 || frameBytes != 4 + frameSamples / 2) {
			throw new IllegalArgumentException("Unsupported relay audio format");
		}
		this.relayRate = relayRate;
		this.frameSamples = frameSamples;
		this.frameBytes = frameBytes;
		this.sender = sender;
	}

	public void start() {
		running = true;
		startThread("SocialTap-call-mic", this::captureLoop);
		startThread("SocialTap-call-speaker", this::playbackLoop);
	}

	public void stop() {
		running = false;
		TargetDataLine mic = microphone;
		if (mic != null) {
			mic.stop();
			mic.close();
		}
		SourceDataLine out = speaker;
		if (out != null) {
			out.stop();
			out.close();
		}
	}

	/** Queues one relay packet from the other person for playback. */
	public void receive(byte[] frame) {
		if (!running || frame.length != frameBytes) return;
		short[] samples = decode(frame, frameSamples);
		// Drop the oldest packet when playback falls behind, to bound the delay.
		while (!playQueue.offer(samples)) playQueue.poll();
	}

	private void captureLoop() {
		try {
			TargetDataLine line = AudioSystem.getTargetDataLine(DEVICE_FORMAT);
			line.open(DEVICE_FORMAT, DEVICE_RATE / 5 * 2);
			microphone = line;
			line.start();
			byte[] buffer = new byte[DEVICE_RATE / 50 * 2]; // 20 ms
			short[] frame = new short[frameSamples];
			int count = 0;
			long phase = 0;
			long sum = 0;
			int sumCount = 0;
			while (running) {
				int read = line.read(buffer, 0, buffer.length);
				if (read <= 0) break;
				for (int i = 0; i + 1 < read; i += 2) {
					sum += (short) ((buffer[i] & 0xFF) | (buffer[i + 1] << 8));
					sumCount++;
					phase += relayRate;
					if (phase < DEVICE_RATE) continue;
					short sample = (short) (sum / sumCount);
					sum = 0;
					sumCount = 0;
					while (phase >= DEVICE_RATE) {
						phase -= DEVICE_RATE;
						frame[count++] = sample;
						if (count == frameSamples) {
							sender.accept(encode(frame));
							count = 0;
						}
					}
				}
			}
		} catch (Exception e) {
			if (running) Log.LOG.warn("Social Tap call: microphone unavailable, you can listen but not talk ({})", e.toString());
		}
	}

	private void playbackLoop() {
		try {
			SourceDataLine line = AudioSystem.getSourceDataLine(DEVICE_FORMAT);
			line.open(DEVICE_FORMAT, DEVICE_RATE / 5 * 2);
			speaker = line;
			line.start();
			int outSamples = (int) ((long) frameSamples * DEVICE_RATE / relayRate);
			byte[] out = new byte[outSamples * 2];
			boolean primed = false;
			while (running) {
				if (!primed) {
					// Three packets of headroom before starting (and after any stall).
					if (playQueue.size() < 3) {
						Thread.sleep(10);
						continue;
					}
					primed = true;
				}
				short[] samples = playQueue.poll(120, TimeUnit.MILLISECONDS);
				if (samples == null) {
					primed = false;
					continue;
				}
				for (int i = 0; i < outSamples; i++) {
					double position = (double) i * relayRate / DEVICE_RATE;
					int left = (int) position;
					int right = Math.min(left + 1, frameSamples - 1);
					double mix = position - left;
					int value = (int) Math.round(samples[left] * (1 - mix) + samples[right] * mix);
					out[i * 2] = (byte) value;
					out[i * 2 + 1] = (byte) (value >> 8);
				}
				line.write(out, 0, out.length);
			}
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		} catch (Exception e) {
			if (running) Log.LOG.warn("Social Tap call: speakers unavailable ({})", e.toString());
		}
	}

	static byte[] encode(short[] samples) {
		byte[] frame = new byte[4 + samples.length / 2];
		int predictor = 0;
		int index = 0;
		for (int i = 0; i < samples.length; i++) {
			int step = STEPS[index];
			int difference = samples[i] - predictor;
			int code = 0;
			if (difference < 0) {
				code = 8;
				difference = -difference;
			}
			if (difference >= step) {
				code |= 4;
				difference -= step;
			}
			if (difference >= step >> 1) {
				code |= 2;
				difference -= step >> 1;
			}
			if (difference >= step >> 2) code |= 1;
			int delta = step >> 3;
			if ((code & 4) != 0) delta += step;
			if ((code & 2) != 0) delta += step >> 1;
			if ((code & 1) != 0) delta += step >> 2;
			predictor = clamp(predictor + ((code & 8) != 0 ? -delta : delta), -32768, 32767);
			index = clamp(index + INDEX[code & 7], 0, 88);
			frame[4 + (i >> 1)] |= (byte) (code << ((i & 1) * 4));
		}
		return frame;
	}

	static short[] decode(byte[] frame, int frameSamples) {
		short[] samples = new short[frameSamples];
		int predictor = 0;
		int index = 0;
		for (int i = 0; i < frameSamples; i++) {
			int code = ((frame[4 + (i >> 1)] & 0xFF) >> ((i & 1) * 4)) & 15;
			int step = STEPS[index];
			int delta = step >> 3;
			if ((code & 4) != 0) delta += step;
			if ((code & 2) != 0) delta += step >> 1;
			if ((code & 1) != 0) delta += step >> 2;
			predictor = clamp(predictor + ((code & 8) != 0 ? -delta : delta), -32768, 32767);
			index = clamp(index + INDEX[code & 7], 0, 88);
			samples[i] = (short) predictor;
		}
		return samples;
	}

	private static int clamp(int value, int min, int max) {
		return Math.max(min, Math.min(max, value));
	}

	private static void startThread(String name, Runnable body) {
		Thread thread = new Thread(body, name);
		thread.setDaemon(true);
		thread.start();
	}

	/** A plain two-tone ring that repeats until stopped. */
	public static final class Ringer {
		private volatile Thread thread;

		public synchronized void start() {
			if (thread != null) return;
			Thread ring = new Thread(() -> {
				AudioFormat format = new AudioFormat(22_050, 16, 1, true, false);
				try (SourceDataLine line = AudioSystem.getSourceDataLine(format)) {
					line.open(format);
					line.start();
					byte[] burst = tone(880, 0.18, 0.05, 880, 0.18, 0.05, 1100, 0.3, 0);
					while (thread == Thread.currentThread()) {
						line.write(burst, 0, burst.length);
						line.drain();
						Thread.sleep(1100);
					}
				} catch (InterruptedException e) {
					// Stopped.
				} catch (Exception e) {
					Log.LOG.debug("Social Tap ringtone unavailable: {}", e.toString());
				}
			}, "SocialTap-ringtone");
			ring.setDaemon(true);
			thread = ring;
			ring.start();
		}

		public synchronized void stop() {
			Thread ring = thread;
			thread = null;
			if (ring != null) ring.interrupt();
		}

		/** Sine tones described as (frequency, seconds, gap seconds) triples. */
		private static byte[] tone(double... parts) {
			java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
			for (int part = 0; part + 2 < parts.length; part += 3) {
				int samples = (int) (parts[part + 1] * 22_050);
				for (int i = 0; i < samples; i++) {
					double fade = Math.min(1, Math.min(i, samples - i) / 220.0);
					int value = (int) (Math.sin(2 * Math.PI * parts[part] * i / 22_050) * 9000 * fade);
					out.write(value);
					out.write(value >> 8);
				}
				int gap = (int) (parts[part + 2] * 22_050);
				for (int i = 0; i < gap * 2; i++) out.write(0);
			}
			return out.toByteArray();
		}
	}
}
