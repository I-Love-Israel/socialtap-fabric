package social.socialtap.core;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;

/**
 * Loot guard. After you kill an enemy player, your world clicks lock for a moment if no other enemy
 * is close enough to the body to still be fighting you. That keeps a reflex click from breaking or
 * placing on the loot while you are crystal PvPing. Friends never count as enemies, and when a
 * friend dies the lock always applies.
 *
 * <p>Nothing here touches Minecraft: each version's client wiring feeds it the loaded players once
 * per tick and asks whether world clicks are locked.
 */
public final class LootGuard {
	/** Another enemy this close to the dead enemy means the fight is still on, so no lock. */
	public static final double SCAN_RADIUS = 30;
	/** A death only counts as your kill when you were this close to the victim when they died. */
	public static final double KILL_RANGE = 12;
	public static final long ENEMY_LOCK_MS = 1500;
	public static final long FRIEND_LOCK_MS = 2000;

	/** A player the game has loaded this tick. */
	public record Player(UUID id, String name, double x, double y, double z, boolean dead) {
	}

	private final Config config;
	private Map<UUID, Boolean> alive = new HashMap<>();
	private volatile long lockedUntilMs;

	public LootGuard(Config config) {
		this.config = config;
	}

	/** True while world clicks should be swallowed. Menus and the Social Tap cards are not affected. */
	public boolean inputLocked() {
		return System.currentTimeMillis() < lockedUntilMs;
	}

	public boolean isFriend(String name) {
		for (String friend : config.friends) {
			if (friend.equalsIgnoreCase(name)) return true;
		}
		return false;
	}

	/**
	 * Call once per client tick. {@code self} is the local player, or null when not in a world;
	 * {@code players} is every player the game has loaded, including yourself.
	 */
	public void tick(Player self, List<Player> players) {
		if (!config.lootGuard || self == null || self.dead()) {
			// Forget who was alive, so a death that happens while this is off or while you are dead
			// is not reported later as a fresh kill.
			alive.clear();
			return;
		}
		Map<UUID, Boolean> next = new HashMap<>();
		for (Player player : players) {
			if (player.id().equals(self.id())) continue;
			Boolean wasAlive = alive.get(player.id());
			if (Boolean.TRUE.equals(wasAlive) && player.dead()) died(player, self, players);
			next.put(player.id(), !player.dead());
		}
		alive = next;
	}

	private void died(Player victim, Player self, List<Player> players) {
		long now = System.currentTimeMillis();
		if (isFriend(victim.name())) {
			lockFor(FRIEND_LOCK_MS, now);
			return;
		}
		if (distance(self, victim) > KILL_RANGE) return;
		for (Player other : players) {
			if (other.dead() || other.id().equals(victim.id()) || other.id().equals(self.id())) continue;
			if (isFriend(other.name())) continue;
			if (distance(other, victim) <= SCAN_RADIUS) return;
		}
		lockFor(ENEMY_LOCK_MS, now);
	}

	private void lockFor(long millis, long now) {
		lockedUntilMs = Math.max(lockedUntilMs, now + millis);
	}

	private static double distance(Player a, Player b) {
		double dx = a.x() - b.x();
		double dy = a.y() - b.y();
		double dz = a.z() - b.z();
		return Math.sqrt(dx * dx + dy * dy + dz * dz);
	}

	// ---- commands (client thread) ----

	/** Reports whether the guard is on, after changing it when {@code enabled} is given. */
	public void setEnabled(Boolean enabled, Consumer<String> feedback) {
		if (enabled != null) {
			config.lootGuard = enabled;
			config.save();
		}
		feedback.accept(config.lootGuard
				? "Social Tap loot guard is ON: after you kill an enemy with no other enemy within " + (int) SCAN_RADIUS
						+ " blocks, world clicks lock for " + ENEMY_LOCK_MS / 1000.0 + " seconds. A friend's death always locks them for "
						+ FRIEND_LOCK_MS / 1000 + " seconds."
				: "Social Tap loot guard is OFF: world clicks are never locked after a kill.");
	}

	public void addFriend(String name, Consumer<String> feedback) {
		String clean = name.trim();
		if (isFriend(clean)) {
			feedback.accept(clean + " is already on your loot guard friends list.");
			return;
		}
		config.friends.add(clean);
		config.save();
		feedback.accept("Added " + clean + ". They are never counted as enemies, and their death always locks clicks for "
				+ FRIEND_LOCK_MS / 1000 + " seconds.");
	}

	public void removeFriend(String name, Consumer<String> feedback) {
		String clean = name.trim();
		boolean removed = config.friends.removeIf(friend -> friend.equalsIgnoreCase(clean));
		if (removed) config.save();
		feedback.accept(removed ? "Removed " + clean + " from your friends list."
				: clean + " is not on your loot guard friends list.");
	}

	public void listFriends(Consumer<String> feedback) {
		feedback.accept(config.friends.isEmpty() ? "No loot guard friends yet. Add one with /socialtap friend add <name>."
				: "Loot guard friends: " + String.join(", ", config.friends));
	}
}
