package social.socialtap.core;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/**
 * Keeps the Social Tap connection alive and turns its events into overlay state. Everything here
 * runs on one background thread ({@link #exec}); the game thread only posts work to it.
 */
public final class SocialTapService implements Overlay.Actions {
	private static final long TOKEN_ROTATE_MS = 10 * 60_000;
	private static final long RING_TIMEOUT_MS = 46_000;
	private static final int MAX_POPUPS_PER_FETCH = 3;
	/** How old a message may be and still count as "just sent" in a chat with no mark of its own. */
	private static final long JUST_SENT_MS = 3 * 60_000;
	/** After being offline this long, what was missed is old news rather than something to replay. */
	private static final long LONG_GAP_MS = 5 * 60_000;

	private final Config config;
	private final OAuth oauth;
	private final Host host;
	private final Overlay overlay = new Overlay();
	private final CallAudio.Ringer ringer = new CallAudio.Ringer();
	private final ScheduledExecutorService exec = Executors.newSingleThreadScheduledExecutor(runnable -> {
		Thread thread = new Thread(runnable, "SocialTap");
		thread.setDaemon(true);
		return thread;
	});

	private volatile SocketIo socket;
	private volatile CallAudio audio;
	private long connectStartedMs;
	private long nextConnectAtMs;
	private int failures;
	private boolean forceRefresh;

	// Message tracking. A message is only ever shown when it is newer than the mark its chat had
	// before the fetch: "lastSeen" per chat once that chat has been looked at, and until then the
	// account-wide "baseline" taken at login plus a check that the message was only just sent.
	private long baseline = -1;
	private final Map<Long, Long> lastSeen = new HashMap<>();
	private final Set<Long> shown = new HashSet<>();
	private final ArrayDeque<Long> primeQueue = new ArrayDeque<>();
	private boolean priming;
	private long clockOffsetMs; // server clock minus ours
	private long lastAliveMs;
	private final Set<Long> pendingChats = new HashSet<>();
	private final Set<Long> knownChats = new HashSet<>();
	private final Map<Long, String> groupNames = new HashMap<>();
	private Long selfId;

	// Relay format of the call being answered.
	private int relayRate;
	private int frameSamples;
	private int frameBytes;

	public SocialTapService(Path configDir, Host host) {
		this.config = Config.load(configDir.resolve("socialtap.json"));
		this.oauth = new OAuth(config);
		this.host = host;
		overlay.setActions(this);
		overlay.setObnoxious(config.obnoxious);
	}

	public Overlay overlay() {
		return overlay;
	}

	public void start() {
		// Development aid: -Dsocialtap.demo=call,message[,quiet] shows the overlays at startup,
		// silently and without logging in or connecting.
		String demo = System.getProperty("socialtap.demo", "");
		if (!demo.isEmpty()) {
			if (demo.contains("quiet")) {
				config.obnoxious = false;
				overlay.setObnoxious(false);
			}
			if (demo.contains("message")) {
				overlay.show(new Overlay.Popup("Test Friend", "This is what a Social Tap message looks like in Minecraft.",
						() -> host.openUrl(chatUrl(0)), 10 * 60_000L));
			}
			if (demo.contains("call")) {
				overlay.setIncoming(new Overlay.IncomingCall("test", 0, "Test Caller", System.currentTimeMillis(), 8000, 400, 204));
			}
			return;
		}

		exec.execute(() -> {
			if (config.effectiveClientId().isEmpty()) {
				notice("Social Tap is not set up", "No client ID yet. Add it as \"client_id\" in config/socialtap.json, then restart the game.");
			} else if (!oauth.loggedIn()) {
				login(null);
			} else {
				connect();
			}
		});
		exec.scheduleWithFixedDelay(this::safeTick, 5, 5, TimeUnit.SECONDS);
	}

	// ---- commands (any thread) ----

	public void login(Consumer<String> feedback) {
		if (config.effectiveClientId().isEmpty()) {
			say(feedback, "No client ID is set. Add \"client_id\" to config/socialtap.json and restart.");
			return;
		}
		Thread thread = new Thread(() -> {
			try {
				say(feedback, "Opening Social Tap in your browser to log in...");
				oauth.login(host);
				notice("Social Tap connected", "Calls and messages will now show up in Minecraft.");
				say(feedback, "Logged in to Social Tap.");
				exec.execute(this::connect);
			} catch (IOException e) {
				Log.LOG.warn("Social Tap login failed: {}", e.getMessage());
				notice("Social Tap login failed", e.getMessage() + " Run /socialtap login to try again.");
				say(feedback, "Login failed: " + e.getMessage());
			}
		}, "SocialTap-login");
		thread.setDaemon(true);
		thread.start();
	}

	public void logout(Consumer<String> feedback) {
		exec.execute(() -> {
			closeSocket();
			oauth.logout();
			say(feedback, "Logged out of Social Tap.");
		});
	}

	public void status(Consumer<String> feedback) {
		exec.execute(() -> {
			SocketIo current = socket;
			String state;
			if (config.effectiveClientId().isEmpty()) state = "no client ID set";
			else if (!oauth.loggedIn()) state = "not logged in (/socialtap login)";
			else if (current != null && current.connected()) state = "connected";
			else state = "logged in, reconnecting";
			say(feedback, "Social Tap: " + state);
		});
	}

	public void testCall() {
		overlay.setIncoming(new Overlay.IncomingCall("test", 0, "Test Caller", System.currentTimeMillis(), 8000, 400, 204));
		if (config.ringtone) ringer.start();
	}

	public void testMessage() {
		String body = config.obnoxious
				? "This is what a Social Tap message looks like in Minecraft. It goes away after "
						+ config.messageSeconds + " seconds, or opens the chat if you click it."
				: "This is a Social Tap message. It goes away after " + config.quietMessageSeconds + " seconds.";
		overlay.show(new Overlay.Popup("Test Friend", body, () -> host.openUrl(chatUrl(0)), popupMs()));
	}

	/** Reports the mode, after changing it when {@code enabled} is given. */
	public void obnoxious(Boolean enabled, Consumer<String> feedback) {
		if (enabled != null) {
			config.obnoxious = enabled;
			overlay.setObnoxious(enabled);
			exec.execute(config::save);
		}
		say(feedback, config.obnoxious
				? "Social Tap obnoxious mode is ON: calls and messages take over the middle of the screen, and any click answers or opens them."
				: "Social Tap obnoxious mode is OFF: calls and messages are small cards in the top-left corner. Messages last "
						+ config.quietMessageSeconds + " seconds and ignore clicks; answer calls with /socialtap answer.");
	}

	public void answerRinging(Consumer<String> feedback) {
		if (!overlay.answer()) say(feedback, "No Social Tap call is ringing.");
	}

	public void declineRinging(Consumer<String> feedback) {
		if (!overlay.decline()) say(feedback, "No Social Tap call is ringing.");
	}

	// ---- overlay actions (client thread) ----

	@Override
	public void respond(Overlay.IncomingCall call) {
		exec.execute(() -> answer(call));
	}

	@Override
	public void decline(Overlay.IncomingCall call) {
		exec.execute(() -> {
			ringer.stop();
			if (isTest(call)) return;
			emit("call:end", callPayload(call.callId(), "declined"), null);
		});
	}

	@Override
	public void hangUp() {
		exec.execute(() -> {
			Overlay.ActiveCall call = overlay.active();
			if (call == null) return;
			emit("call:end", callPayload(call.callId, "ended"), null);
			endCallLocally();
		});
	}

	// ---- connection ----

	private void safeTick() {
		try {
			tick();
		} catch (Exception e) {
			Log.LOG.warn("Social Tap tick failed", e);
		}
	}

	private void tick() {
		long now = System.currentTimeMillis();
		Overlay.IncomingCall ringing = overlay.incoming();
		if (ringing != null && now - ringing.atMs() > RING_TIMEOUT_MS) {
			overlay.setIncoming(null);
			ringing = null;
		}
		if (ringing == null) ringer.stop();

		if (config.effectiveClientId().isEmpty() || !oauth.loggedIn() || oauth.loginInProgress()) return;
		SocketIo current = socket;
		if (current == null) {
			if (now >= nextConnectAtMs) connect();
			return;
		}
		boolean busy = ringing != null || overlay.active() != null;
		if (current.connected()) {
			if (!current.stale()) lastAliveMs = now;
			if (current.stale()) {
				disconnected(current, "no heartbeat");
			} else if (!busy && oauth.tokenAgeMs() > TOKEN_ROTATE_MS) {
				// Access tokens last 15 minutes and are checked on every event: move to a new one.
				connect();
			}
		} else if (now - connectStartedMs > 30_000) {
			disconnected(current, "connect timed out");
		}
	}

	private void connect() {
		closeSocket();
		if (!oauth.loggedIn()) return;
		String token;
		try {
			token = forceRefresh ? oauth.refresh() : oauth.token();
			forceRefresh = false;
		} catch (OAuth.LoggedOutException e) {
			Log.LOG.warn("{}", e.getMessage());
			notice("Social Tap logged out", "Your login expired or was revoked. Run /socialtap login to reconnect.");
			return;
		} catch (IOException e) {
			Log.LOG.warn("Could not refresh the Social Tap token: {}", e.toString());
			backOff();
			return;
		}

		SocketIo next = new SocketIo(exec);
		socket = next;
		connectStartedMs = System.currentTimeMillis();
		next.onConnect(() -> exec.execute(() -> {
			if (socket == next) connected(next);
		}));
		next.onDisconnect(reason -> exec.execute(() -> disconnected(next, reason)));
		next.on("chat:changed", (data, attachments) -> exec.execute(() -> chatChanged(data)));
		next.on("call:incoming", (data, attachments) -> exec.execute(() -> callIncoming(data)));
		next.on("call:claimed", (data, attachments) -> exec.execute(() -> callClaimed(next, data)));
		next.on("call:ended", (data, attachments) -> exec.execute(() -> callEnded(data)));
		next.on("call:relay:start", (data, attachments) -> exec.execute(() -> relayStarted(data)));
		next.on("call:audio", (data, attachments) -> {
			CallAudio playing = audio;
			if (playing != null && !attachments.isEmpty()) playing.receive(attachments.get(0));
		});
		JsonObject auth = new JsonObject();
		auth.addProperty("access_token", token);
		next.connect(oauth.http(), Constants.BASE_URL, auth);
	}

	private void connected(SocketIo current) {
		failures = 0;
		Log.LOG.info("Connected to Social Tap");
		long now = System.currentTimeMillis();
		boolean longGap = lastAliveMs > 0 && now - lastAliveMs > LONG_GAP_MS;
		lastAliveMs = now;
		fetchChats();
		JsonObject request = new JsonObject();
		request.addProperty("since", Math.max(0, baseline));
		current.emit("notifications:get", request, envelope -> exec.execute(() -> {
			if (socket != current) return;
			List<JsonObject> updates = new ArrayList<>();
			long newest = 0;
			if (SocketIo.statusOf(envelope) == 200 && dataOf(envelope).isJsonObject()) {
				JsonObject data = envelope.getAsJsonObject("data");
				newest = longOf(data, "since");
				if (data.has("updates") && data.get("updates").isJsonArray()) {
					for (JsonElement element : data.getAsJsonArray("updates")) {
						if (!element.isJsonObject()) continue;
						JsonObject update = element.getAsJsonObject();
						updates.add(update);
						// The returned "since" can be 0 when nothing is unread, so take the newest
						// message ID from the unread and read cursors as well.
						newest = Math.max(newest, Math.max(longOf(update, "last_message_id"), longOf(update, "last_read_message_id")));
					}
				}
			}
			if (baseline < 0 || longGap) {
				// Just logged in, or back after a long time away: everything up to here is old news.
				baseline = Math.max(baseline, newest);
				for (JsonObject update : updates) {
					long latest = longOf(update, "last_message_id");
					if (latest > 0) lastSeen.merge(longOf(update, "chat_id"), latest, Math::max);
				}
			} else {
				// A short reconnect: the server does not replay events, so catch up on what was missed.
				for (JsonObject update : updates) {
					if (longOf(update, "new_messages") > 0) queueChat(longOf(update, "chat_id"));
				}
			}
			primeChats();
		}));
	}

	/**
	 * Looks at every chat once, without showing anything, so each one has its own mark. Without
	 * this, the first event in a chat (a message of ours, a deleted message, a finished call) would
	 * hand back its history and the newest old message would pop up as if it had just arrived.
	 */
	private void primeChats() {
		for (long chatId : knownChats) {
			if (!lastSeen.containsKey(chatId) && !primeQueue.contains(chatId)) primeQueue.add(chatId);
		}
		if (config.showGlobalChat && !lastSeen.containsKey(0L) && !primeQueue.contains(0L)) primeQueue.add(0L);
		if (!priming) primeNext();
	}

	private void primeNext() {
		Long chatId = primeQueue.poll();
		while (chatId != null && lastSeen.containsKey(chatId)) chatId = primeQueue.poll();
		if (chatId == null) {
			priming = false;
			return;
		}
		priming = true;
		long chat = chatId;
		long floor = Math.max(0, baseline);
		JsonObject request = new JsonObject();
		request.addProperty("chat_id", chat);
		if (floor > 0) request.addProperty("last_id", floor);
		SocketIo owner = socket;
		emit("messages:get", request, envelope -> {
			if (socket != owner) return; // a newer connection has started its own pass
			int status = SocketIo.statusOf(envelope);
			if (status == 200 && dataOf(envelope).isJsonArray()) {
				long newest = floor;
				for (JsonElement element : envelope.getAsJsonArray("data")) {
					if (element.isJsonObject()) newest = Math.max(newest, longOf(element.getAsJsonObject(), "id"));
				}
				lastSeen.merge(chat, newest, Math::max);
			}
			if (status == 0) {
				// Not connected, or no answer: the next connection starts this again.
				primeQueue.clear();
				priming = false;
				return;
			}
			primeNext();
		});
	}

	private void disconnected(SocketIo current, String reason) {
		if (socket != current) return;
		Log.LOG.info("Social Tap disconnected: {}", reason);
		if (reason.startsWith("connect_error")) forceRefresh = true;
		closeSocket();
		backOff();
	}

	private void backOff() {
		failures = Math.min(failures + 1, 5);
		nextConnectAtMs = System.currentTimeMillis() + Math.min(60_000, 2_000L << failures);
	}

	private void closeSocket() {
		SocketIo current = socket;
		socket = null;
		if (current != null) current.close();
		primeQueue.clear();
		priming = false;
		// A call cannot outlive the socket that owns it.
		ringer.stop();
		overlay.setIncoming(null);
		endCallLocally();
	}

	private void emit(String event, JsonObject data, Consumer<JsonObject> ack) {
		SocketIo current = socket;
		if (current == null) {
			if (ack != null) {
				JsonObject envelope = new JsonObject();
				envelope.addProperty("status", 0);
				envelope.addProperty("error", "not connected");
				ack.accept(envelope);
			}
			return;
		}
		current.emit(event, data, ack == null ? null : envelope -> exec.execute(() -> ack.accept(envelope)));
	}

	// ---- messages ----

	private void chatChanged(JsonElement data) {
		long chatId = data != null && data.isJsonObject() ? longOf(data.getAsJsonObject(), "chat_id") : 0;
		if (chatId > 0 && !knownChats.contains(chatId)) fetchChats();
		queueChat(chatId);
	}

	private void queueChat(long chatId) {
		if (chatId == 0 && !config.showGlobalChat) return;
		boolean first = pendingChats.isEmpty();
		pendingChats.add(chatId);
		// Several events for one send (message + read cursor) collapse into one fetch.
		if (first) exec.schedule(this::flushChats, 250, TimeUnit.MILLISECONDS);
	}

	private void flushChats() {
		List<Long> chats = new ArrayList<>(pendingChats);
		pendingChats.clear();
		for (long chatId : chats) fetchNewMessages(chatId);
	}

	private void fetchNewMessages(long chatId) {
		// Both taken now, not when the answer arrives: a message that came in between is still new.
		boolean marked = lastSeen.containsKey(chatId);
		long last = Math.max(0, lastSeen.getOrDefault(chatId, baseline));
		JsonObject request = new JsonObject();
		request.addProperty("chat_id", chatId);
		if (last > 0) request.addProperty("last_id", last);
		emit("messages:get", request, envelope -> {
			int status = SocketIo.statusOf(envelope);
			if (status == 401) {
				forceRefresh = true;
				connect();
				return;
			}
			if (status != 200 || !dataOf(envelope).isJsonArray()) {
				if (status != 0) Log.LOG.debug("messages:get failed: {}", SocketIo.errorOf(envelope));
				return;
			}
			List<JsonObject> fresh = new ArrayList<>();
			long newest = last;
			long serverNow = System.currentTimeMillis() + clockOffsetMs;
			for (JsonElement element : envelope.getAsJsonArray("data")) {
				JsonObject message = element.getAsJsonObject();
				long id = longOf(message, "id");
				newest = Math.max(newest, id);
				if (id <= last || shown.contains(id)) continue;
				if (message.has("call") && !message.get("call").isJsonNull()) continue; // call history
				if (selfId != null && longOf(message, "sender_user_id") == selfId) continue;
				// A chat with no mark of its own may hand back history: keep only what was just sent.
				if (!marked && !justSent(message, serverNow)) continue;
				fresh.add(message);
			}
			lastSeen.merge(chatId, newest, Math::max);
			if (fresh.isEmpty()) return;
			if (selfId != null) {
				showMessages(chatId, fresh, fresh.size());
			} else {
				// We could not work out which account is ours, so ask the server how many of these
				// are from other people (its unread count leaves out our own messages).
				List<JsonObject> candidates = fresh;
				JsonObject counts = new JsonObject();
				counts.addProperty("since", Math.max(0, last));
				emit("notifications:get", counts, reply -> showMessages(chatId, candidates, unreadFor(chatId, reply)));
			}
		});
	}

	private static int unreadFor(long chatId, JsonObject envelope) {
		if (SocketIo.statusOf(envelope) != 200 || !dataOf(envelope).isJsonObject()) return 0;
		JsonObject data = envelope.getAsJsonObject("data");
		if (!data.has("updates")) return 0;
		for (JsonElement element : data.getAsJsonArray("updates")) {
			JsonObject update = element.getAsJsonObject();
			if (longOf(update, "chat_id") == chatId) return (int) longOf(update, "new_messages");
		}
		return 0;
	}

	/** True when the message's own timestamp says it was sent in the last few minutes. */
	private static boolean justSent(JsonObject message, long serverNow) {
		String stamp = stringOf(message, "timestamp_iso", "");
		long sentAt;
		try {
			sentAt = OffsetDateTime.parse(stamp).toInstant().toEpochMilli();
		} catch (DateTimeParseException e) {
			try {
				sentAt = LocalDateTime.parse(stamp).toInstant(ZoneOffset.UTC).toEpochMilli();
			} catch (DateTimeParseException unreadable) {
				return false;
			}
		}
		return serverNow - sentAt <= JUST_SENT_MS;
	}

	private void showMessages(long chatId, List<JsonObject> messages, int count) {
		int show = Math.min(Math.min(count, messages.size()), MAX_POPUPS_PER_FETCH);
		if (shown.size() > 2000) shown.clear();
		for (JsonObject message : messages) shown.add(longOf(message, "id"));
		for (JsonObject message : messages.subList(messages.size() - show, messages.size())) {
			String sender = stringOf(message, "username", "Someone");
			String where = chatId == 0 ? " in Global Chat" : groupNames.containsKey(chatId) ? " in " + groupNames.get(chatId) : "";
			String body = stringOf(message, "content", "");
			if (body.isBlank()) body = "Sent an attachment";
			overlay.show(new Overlay.Popup(sender + where, body, () -> host.openUrl(chatUrl(chatId)), popupMs()));
		}
	}

	/** Loads chat names and works out our own user ID (the one member every chat has in common). */
	private void fetchChats() {
		try {
			HttpRequest request = HttpRequest.newBuilder(URI.create(Constants.BASE_URL + "/api/chats"))
					.timeout(Duration.ofSeconds(10))
					.header("Authorization", "Bearer " + oauth.token())
					.header("Accept", "application/json")
					.header("User-Agent", Constants.USER_AGENT)
					.GET().build();
			HttpResponse<String> response = oauth.http().send(request, HttpResponse.BodyHandlers.ofString());
			response.headers().firstValue("date").ifPresent(date -> {
				try {
					clockOffsetMs = ZonedDateTime.parse(date, DateTimeFormatter.RFC_1123_DATE_TIME).toInstant().toEpochMilli()
							- System.currentTimeMillis();
				} catch (DateTimeParseException e) {
					// Keep trusting our own clock.
				}
			});
			if (response.statusCode() != 200) return;
			JsonArray chats = JsonParser.parseString(response.body()).getAsJsonArray();
			Set<Long> common = null;
			for (JsonElement element : chats) {
				JsonObject chat = element.getAsJsonObject();
				long id = longOf(chat, "id");
				knownChats.add(id);
				boolean isPrivate = chat.has("is_private") && chat.get("is_private").getAsBoolean();
				if (!isPrivate) groupNames.put(id, stringOf(chat, "name", "a group"));
				Set<Long> members = new HashSet<>();
				if (chat.has("participants") && chat.get("participants").isJsonArray()) {
					for (JsonElement participant : chat.getAsJsonArray("participants")) {
						members.add(longOf(participant.getAsJsonObject(), "id"));
					}
				}
				if (members.isEmpty()) continue;
				if (common == null) common = members;
				else common.retainAll(members);
			}
			if (common != null && common.size() == 1) selfId = common.iterator().next();
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		} catch (Exception e) {
			Log.LOG.debug("Could not load Social Tap chats: {}", e.toString());
		}
	}

	// ---- calls ----

	private void callIncoming(JsonElement element) {
		if (!element.isJsonObject() || overlay.active() != null) return;
		JsonObject data = element.getAsJsonObject();
		int rate = 16_000;
		int samples = 800;
		int bytes = 404;
		if (data.has("relay_audio") && data.get("relay_audio").isJsonObject()) {
			JsonObject relay = data.getAsJsonObject("relay_audio");
			rate = (int) longOf(relay, "sample_rate");
			samples = (int) longOf(relay, "frame_samples");
			bytes = (int) longOf(relay, "frame_bytes");
		}
		overlay.setIncoming(new Overlay.IncomingCall(stringOf(data, "call_id", ""), longOf(data, "chat_id"),
				stringOf(data, "username", "Someone"), System.currentTimeMillis(), rate, samples, bytes));
		if (config.ringtone) ringer.start();
	}

	private void callClaimed(SocketIo current, JsonElement element) {
		if (!element.isJsonObject()) return;
		JsonObject data = element.getAsJsonObject();
		Overlay.IncomingCall ringing = overlay.incoming();
		// Picked up on another device or tab.
		if (ringing != null && ringing.callId().equals(stringOf(data, "call_id", ""))
				&& !current.sid().equals(stringOf(data, "sid", ""))) {
			overlay.setIncoming(null);
			ringer.stop();
		}
	}

	private void callEnded(JsonElement element) {
		if (!element.isJsonObject()) return;
		JsonObject data = element.getAsJsonObject();
		String callId = stringOf(data, "call_id", "");
		Overlay.IncomingCall ringing = overlay.incoming();
		if (ringing != null && ringing.callId().equals(callId)) {
			overlay.setIncoming(null);
			ringer.stop();
			long chatId = ringing.chatId();
			overlay.show(new Overlay.Popup("Missed call", ringing.username() + " called you on Social Tap.",
					() -> host.openUrl(chatUrl(chatId)), popupMs()));
		}
		Overlay.ActiveCall call = overlay.active();
		if (call != null && call.callId.equals(callId)) endCallLocally();
	}

	private void answer(Overlay.IncomingCall incoming) {
		ringer.stop();
		if (isTest(incoming)) {
			notice("Test call answered", "A real call would now connect your microphone and speakers.");
			return;
		}
		relayRate = incoming.relayRate();
		frameSamples = incoming.frameSamples();
		frameBytes = incoming.frameBytes();
		Overlay.ActiveCall call = new Overlay.ActiveCall(incoming.callId(), incoming.chatId(), incoming.username());
		overlay.setActive(call);
		// Claim the call first, then ask the server to relay audio, then open the microphone.
		emit("call:accept", callPayload(call.callId, null), accepted -> {
			if (overlay.active() != call) return;
			if (SocketIo.statusOf(accepted) != 200) {
				failCall(call, SocketIo.errorOf(accepted));
				return;
			}
			if (dataOf(accepted).isJsonObject() && accepted.getAsJsonObject("data").has("relay_audio")
					&& accepted.getAsJsonObject("data").get("relay_audio").isJsonObject()) {
				JsonObject relay = accepted.getAsJsonObject("data").getAsJsonObject("relay_audio");
				relayRate = (int) longOf(relay, "sample_rate");
				frameSamples = (int) longOf(relay, "frame_samples");
				frameBytes = (int) longOf(relay, "frame_bytes");
			}
			emit("call:relay:start", callPayload(call.callId, null), relaying -> {
				if (overlay.active() != call) return;
				if (SocketIo.statusOf(relaying) != 200) failCall(call, SocketIo.errorOf(relaying));
				else startAudio(call);
			});
		});
	}

	private void relayStarted(JsonElement element) {
		Overlay.ActiveCall call = overlay.active();
		if (call != null && element.isJsonObject() && call.callId.equals(stringOf(element.getAsJsonObject(), "call_id", ""))) {
			startAudio(call);
		}
	}

	private void startAudio(Overlay.ActiveCall call) {
		if (audio != null) return;
		try {
			CallAudio started = new CallAudio(relayRate, frameSamples, frameBytes, frame -> {
				SocketIo current = socket;
				if (current != null) current.emitBinary("call:audio", callPayload(call.callId, null), "frame", frame);
			});
			started.start();
			audio = started;
		} catch (IllegalArgumentException e) {
			failCall(call, e.getMessage());
			return;
		}
		call.connectedAtMs = System.currentTimeMillis();
		call.connected = true;
		emit("call:connected", callPayload(call.callId, null), null);
	}

	private void failCall(Overlay.ActiveCall call, String reason) {
		Log.LOG.warn("Social Tap call failed: {}", reason);
		emit("call:end", callPayload(call.callId, "connection_issue"), null);
		endCallLocally();
		notice("Call failed", reason);
	}

	private void endCallLocally() {
		CallAudio playing = audio;
		audio = null;
		if (playing != null) playing.stop();
		overlay.setActive(null);
	}

	// ---- helpers ----

	private static boolean isTest(Overlay.IncomingCall call) {
		return "test".equals(call.callId());
	}

	private static JsonObject callPayload(String callId, String reason) {
		JsonObject payload = new JsonObject();
		payload.addProperty("call_id", callId);
		if (reason != null) payload.addProperty("reason", reason);
		return payload;
	}

	private static String chatUrl(long chatId) {
		return chatId > 0 ? Constants.BASE_URL + "/chat/" + chatId : Constants.BASE_URL + "/";
	}

	private void notice(String title, String body) {
		overlay.show(new Overlay.Popup(title, body, null, popupMs()));
	}

	/** How long a popup stays: 10 seconds in the middle of the screen, 5 in the quiet corner. */
	private long popupMs() {
		return (config.obnoxious ? config.messageSeconds : config.quietMessageSeconds) * 1000L;
	}

	private static void say(Consumer<String> feedback, String message) {
		if (feedback != null) feedback.accept(message);
	}

	private static JsonElement dataOf(JsonObject envelope) {
		JsonElement data = envelope.get("data");
		return data == null ? com.google.gson.JsonNull.INSTANCE : data;
	}

	private static long longOf(JsonObject object, String key) {
		JsonElement value = object.get(key);
		try {
			return value == null || value.isJsonNull() ? 0 : value.getAsLong();
		} catch (Exception e) {
			return 0;
		}
	}

	private static String stringOf(JsonObject object, String key, String fallback) {
		JsonElement value = object.get(key);
		return value == null || !value.isJsonPrimitive() ? fallback : value.getAsString();
	}
}
