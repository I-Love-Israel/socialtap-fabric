package social.socialtap.core;

import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.net.URI;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/**
 * Keeps the Social Tap connection alive and turns its events into overlay state. Everything here
 * runs on one background thread ({@link #exec}); the game thread only posts work to it.
 */
public final class SocialTapService implements Overlay.Actions {
	private static final long TOKEN_ROTATE_MS = 10 * 60_000;
	private static final long RING_TIMEOUT_MS = 46_000;
	private static final int MAX_POPUPS_PER_FETCH = 3;
	/** How old a message may be and still count as "just sent" in a chat with no mark of its own. */
	private static final long JUST_SENT_MS = 3 * 60_000;
	/** After being offline this long, what was missed is old news rather than something to replay. */
	private static final long LONG_GAP_MS = 5 * 60_000;
	/** The activity card expires 15 minutes after its last update; this keeps it well clear of that. */
	private static final long CARD_REFRESH_MS = 5 * 60_000;
	private static final long CARD_RETRY_MS = 60_000;

	private final Config config;
	private final OAuth oauth;
	private final Host host;
	private final Overlay overlay = new Overlay();
	private final CallAudio.Ringer ringer = new CallAudio.Ringer();
	private final ScheduledExecutorService exec = Executors.newSingleThreadScheduledExecutor(runnable -> {
		Thread thread = new Thread(runnable, "SocialTap");
		thread.setDaemon(true);
		return thread;
	});

	private volatile SocketIo socket;
	private volatile CallAudio audio;
	private long connectStartedMs;
	private long nextConnectAtMs;
	private int failures;
	private boolean forceRefresh;

	// Message tracking. A message is only ever shown when it is newer than the mark its chat had
	// before the fetch: "lastSeen" per chat once that chat has been looked at, and until then the
	// account-wide "baseline" taken at login plus a check that the message was only just sent.
	private long baseline = -1;
	private final Map<Long, Long> lastSeen = new HashMap<>();
	private final Set<Long> shown = new HashSet<>();
	private final ArrayDeque<Long> primeQueue = new ArrayDeque<>();
	private boolean priming;
	private long clockOffsetMs; // server clock minus ours
	private long lastAliveMs;
	private final Set<Long> pendingChats = new HashSet<>();
	private final Set<Long> knownChats = new HashSet<>();
	private final Map<Long, String> groupNames = new HashMap<>();
	private Long selfId;

	/** A one-to-one chat, found by the other person's name for /respond. */
	private record DirectChat(long chatId, String username) {
	}

	// Lower-cased username (and profile name) -> direct chat. Rebuilt by fetchChats.
	private volatile Map<String, DirectChat> directChats = Map.of();
	private volatile List<String> directNames = List.of();

	// ---- the Social Tap window (ChatPanel) ----

	/** A row in the window's chat list. {@code callable}: exactly two people, so calls are allowed. */
	public record ChatInfo(long id, String name, boolean group, boolean callable, boolean online, int unread) {
		ChatInfo withUnread(int count) {
			return new ChatInfo(id, name, group, callable, online, count);
		}
	}

	/** One line of history. {@code note}: not something someone typed (a call record). */
	public record ChatMessage(long id, String username, String text, String time, boolean mine, boolean note) {
	}

	/** The open chat's history. Written by the background thread, read while drawing. */
	public static final class History {
		public final long chatId;
		public volatile List<ChatMessage> messages = List.of();
		public volatile boolean loading = true;
		public volatile String error = "";

		History(long chatId) {
			this.chatId = chatId;
		}
	}

	private static final long OUTGOING_RING_MS = 60_000;

	private volatile List<ChatInfo> chatList = List.of();
	private List<ChatInfo> baseChats = List.of(); // chatList without unread counts
	private final Map<Long, Integer> unread = new HashMap<>();
	private volatile boolean panelOpen;
	private volatile long viewedChat = -1;
	private volatile History viewed;
	private boolean demo;

	// Relay format of the call being answered.
	private int relayRate;
	private int frameSamples;
	private int frameBytes;

	// Activity card ("Minecraft 1.21.4 / play.example.net"). The game thread sets what is happening;
	// the background thread publishes it when it changes and keeps it from expiring.
	private final long playingSinceMs = ManagementFactory.getRuntimeMXBean().getStartTime();
	private volatile String activityTitle = "";
	private volatile String activityDetail = "";
	private volatile boolean cardLive;
	private String publishedCard = "";
	private long publishedAtMs;
	private long statusRetryAtMs;
	private boolean statusBusy;
	private boolean statusBlocked;

	public SocialTapService(Path configDir, Host host) {
		this.config = Config.load(configDir.resolve("socialtap.json"));
		this.oauth = new OAuth(config);
		this.host = host;
		overlay.setActions(this);
		overlay.setObnoxious(config.obnoxious);
	}

	public Overlay overlay() {
		return overlay;
	}

	public void start() {
		// Development aid: -Dsocialtap.demo=call,message[,quiet] shows the overlays at startup,
		// silently and without logging in or connecting.
		String demo = System.getProperty("socialtap.demo", "");
		if (!demo.isEmpty()) {
			startDemoPanel();
			if (demo.contains("quiet")) {
				config.obnoxious = false;
				overlay.setObnoxious(false);
			}
			if (demo.contains("message")) {
				overlay.show(new Overlay.Popup("Test Friend", "This is what a Social Tap message looks like in Minecraft.",
						() -> host.openUrl(chatUrl(0)), 10 * 60_000L));
			}
			if (demo.matches(".*(^|,)call($|,).*")) {
				overlay.setIncoming(new Overlay.IncomingCall("test", 0, "Test Caller", System.currentTimeMillis(), 8000, 400, 204));
			}
			if (demo.contains("incall")) {
				Overlay.ActiveCall call = new Overlay.ActiveCall("test", 1, "Test Friend");
				call.connectedAtMs = System.currentTimeMillis() - 83_000;
				call.connected = true;
				overlay.setActive(call);
			}
			return;
		}

		exec.execute(() -> {
			if (config.effectiveClientId().isEmpty()) {
				notice("Social Tap is not set up", "No client ID yet. Add it as \"client_id\" in config/socialtap.json, then restart the game.");
			} else if (!oauth.loggedIn()) {
				login(null);
			} else {
				connect();
			}
		});
		exec.scheduleWithFixedDelay(this::safeTick, 5, 5, TimeUnit.SECONDS);
	}

	// ---- commands (any thread) ----

	public void login(Consumer<String> feedback) {
		if (config.effectiveClientId().isEmpty()) {
			say(feedback, "No client ID is set. Add \"client_id\" to config/socialtap.json and restart.");
			return;
		}
		Thread thread = new Thread(() -> {
			try {
				say(feedback, "Opening Social Tap in your browser to log in...");
				for (int attempt = 0; ; attempt++) {
					String scopes = Constants.SCOPE_FALLBACKS[attempt];
					try {
						oauth.login(host, scopes);
						break;
					} catch (IOException e) {
						boolean scopeRefused = e.getMessage() != null && e.getMessage().contains("invalid_scope");
						if (!scopeRefused || attempt == Constants.SCOPE_FALLBACKS.length - 1) throw e;
						// The app in the developer dashboard lacks an optional permission (showing
						// activity, sending messages): try again asking for less.
						Log.LOG.warn("Social Tap refused the scopes \"{}\"; trying \"{}\"", scopes, Constants.SCOPE_FALLBACKS[attempt + 1]);
					}
				}
				notice("Social Tap connected", "Calls and messages will now show up in Minecraft.");
				say(feedback, "Logged in to Social Tap.");
				exec.execute(() -> {
					// A new login may carry the activity permission the old one lacked.
					statusBlocked = false;
					statusRetryAtMs = 0;
					publishedCard = "";
					connect();
				});
			} catch (IOException e) {
				Log.LOG.warn("Social Tap login failed: {}", e.getMessage());
				notice("Social Tap login failed", e.getMessage() + " Run /socialtap login to try again.");
				say(feedback, "Login failed: " + e.getMessage());
			}
		}, "SocialTap-login");
		thread.setDaemon(true);
		thread.start();
	}

	public void logout(Consumer<String> feedback) {
		exec.execute(() -> {
			closeSocket();
			clearCardNow();
			oauth.logout();
			say(feedback, "Logged out of Social Tap.");
		});
	}

	/** Reports whether the activity card is on, after changing it when {@code enabled} is given. */
	public void activity(Boolean enabled, Consumer<String> feedback) {
		if (enabled != null) {
			config.activityStatus = enabled;
			exec.execute(() -> {
				config.save();
				safeActivityTick();
			});
		}
		say(feedback, config.activityStatus
				? "Social Tap activity is ON: your profile shows your Minecraft version, where you are playing and for how long."
				: "Social Tap activity is OFF: your profile does not show that you are playing Minecraft.");
	}

	/** What the game is doing right now. The client thread calls this about once a second. */
	public void setActivity(String title, String detail) {
		activityTitle = clean(title, 128);
		activityDetail = clean(detail, 200);
	}

	/** The game is closing: take the card down rather than leave it up until it expires. */
	public void shutdown() {
		clearCardNow();
	}

	public void status(Consumer<String> feedback) {
		exec.execute(() -> {
			SocketIo current = socket;
			String state;
			if (config.effectiveClientId().isEmpty()) state = "no client ID set";
			else if (!oauth.loggedIn()) state = "not logged in (/socialtap login)";
			else if (current != null && current.connected()) state = "connected";
			else state = "logged in, reconnecting";
			say(feedback, "Social Tap: " + state);
		});
	}

	public void testCall() {
		overlay.setIncoming(new Overlay.IncomingCall("test", 0, "Test Caller", System.currentTimeMillis(), 8000, 400, 204));
		if (config.ringtone) ringer.start();
	}

	public void testMessage() {
		String body = config.obnoxious
				? "This is what a Social Tap message looks like in Minecraft. It goes away after "
						+ config.messageSeconds + " seconds, or opens the chat if you click it."
				: "This is a Social Tap message. It goes away after " + config.quietMessageSeconds + " seconds.";
		overlay.show(new Overlay.Popup("Test Friend", body, () -> host.openUrl(chatUrl(0)), popupMs()));
	}

	/** Reports the mode, after changing it when {@code enabled} is given. */
	public void obnoxious(Boolean enabled, Consumer<String> feedback) {
		if (enabled != null) {
			config.obnoxious = enabled;
			overlay.setObnoxious(enabled);
			exec.execute(config::save);
		}
		say(feedback, config.obnoxious
				? "Social Tap obnoxious mode is ON: calls and messages take over the middle of the screen, and any click answers or opens them."
				: "Social Tap obnoxious mode is OFF: calls and messages are small cards in the top-left corner. Messages last "
						+ config.quietMessageSeconds + " seconds and ignore clicks; answer calls with /socialtap answer.");
	}

	/** People you have a one-to-one chat with, for tab completion. Safe from any thread. */
	public List<String> directChatNames() {
		return directNames;
	}

	/** /respond: sends {@code text} to your one-to-one chat with {@code name}. */
	public void sendMessage(String name, String text, Consumer<String> feedback) {
		String message = text == null ? "" : text.strip();
		if (message.isEmpty()) {
			say(feedback, "Usage: /respond <username> <message>");
			return;
		}
		if (message.length() > 500) {
			say(feedback, "That message is " + message.length() + " characters; Social Tap allows 500.");
			return;
		}
		exec.execute(() -> {
			if (!oauth.loggedIn()) {
				say(feedback, "You are not logged in to Social Tap. Run /socialtap login first.");
				return;
			}
			if (oauth.knownToLack(Constants.SEND_SCOPE)) {
				say(feedback, "Your Social Tap login does not allow sending messages yet. Run /socialtap login and approve it again.");
				return;
			}
			DirectChat chat = directChats.get(nameKey(name));
			if (chat == null) {
				fetchChats(); // maybe a chat that started after we connected
				chat = directChats.get(nameKey(name));
			}
			if (chat == null) {
				say(feedback, "You do not have a one-to-one chat with " + name + " on Social Tap. Start one on socialtap.social first.");
				return;
			}
			DirectChat to = chat;
			sendToChat(to.chatId(), message, feedback, sent -> say(feedback, "To " + to.username() + ": " + message));
		});
	}

	/**
	 * Sends from the Social Tap window. {@code onError} gets a sentence to show; {@code onSent} runs
	 * once Social Tap has the message. Both are called on the background thread.
	 */
	public void sendFromPanel(long chatId, String text, Consumer<String> onError, Runnable onSent) {
		String message = text == null ? "" : text.strip();
		if (message.isEmpty()) return;
		if (message.length() > 500) {
			onError.accept("That is " + message.length() + " characters; Social Tap allows 500.");
			return;
		}
		if (demo) {
			History open = viewed;
			if (open != null && open.chatId == chatId) {
				List<ChatMessage> next = new ArrayList<>(open.messages);
				next.add(new ChatMessage(System.nanoTime(), "You", message, "now", true, false));
				open.messages = List.copyOf(next);
			}
			onSent.run();
			return;
		}
		exec.execute(() -> {
			if (!oauth.loggedIn()) {
				onError.accept("Not logged in. Run /socialtap login.");
				return;
			}
			if (oauth.knownToLack(Constants.SEND_SCOPE)) {
				onError.accept("Your login cannot send messages yet. Run /socialtap login and approve it again.");
				return;
			}
			sendToChat(chatId, message, onError, sent -> {
				History open = viewed;
				if (open != null && open.chatId == chatId && sent.id() > 0) {
					List<ChatMessage> next = new ArrayList<>(open.messages);
					if (next.stream().noneMatch(m -> m.id() == sent.id())) next.add(sent);
					open.messages = List.copyOf(next);
					lastSeen.merge(chatId, sent.id(), Math::max);
				}
				onSent.run();
			});
		});
	}

	/** Background thread. Reports failures to {@code feedback} and success to {@code onSent}. */
	private void sendToChat(long chatId, String message, Consumer<String> feedback, Consumer<ChatMessage> onSent) {
		JsonObject request = new JsonObject();
		request.addProperty("chat_id", chatId);
		request.addProperty("message", message);
		emit("message:send", request, ack -> {
			int status = SocketIo.statusOf(ack);
			if (status == 200) {
				JsonElement sent = dataOf(ack);
				JsonObject record = sent.isJsonObject() && sent.getAsJsonObject().has("message")
						&& sent.getAsJsonObject().get("message").isJsonObject()
						? sent.getAsJsonObject().getAsJsonObject("message")
						: sent.isJsonObject() ? sent.getAsJsonObject() : new JsonObject();
				long id = longOf(record, "id");
				if (id > 0) shown.add(id); // never pop up our own message
				long sender = longOf(record, "sender_user_id");
				if (selfId == null && sender > 0) selfId = sender;
				onSent.accept(toChatMessage(record, true));
			} else if (status == 0 && "not connected".equals(SocketIo.errorOf(ack))) {
				say(feedback, "Not connected to Social Tap right now. Try again in a moment.");
			} else if (status == 0) {
				say(feedback, "No answer from Social Tap, so it may or may not have sent. Check the chat before sending again.");
			} else if (status == 429) {
				say(feedback, "Too fast: Social Tap allows one message every 2 seconds. Try again.");
			} else if (status == 401) {
				forceRefresh = true;
				connect();
				say(feedback, "Social Tap needed a fresh login token. Try again in a moment.");
			} else {
				String error = SocketIo.errorOf(ack);
				String lower = error.toLowerCase(java.util.Locale.ROOT);
				String hint = status == 403 && (lower.contains("scope") || lower.contains("permission"))
						? " Run /socialtap login and approve sending messages."
						: "";
				say(feedback, "Social Tap did not send it: " + error + "." + hint);
			}
		});
	}

	// ---- the Social Tap window: data (any thread) ----

	public List<ChatInfo> chats() {
		return chatList;
	}

	public long viewedChat() {
		return viewedChat;
	}

	public History viewedHistory() {
		return viewed;
	}

	/** Connected, reconnecting, or why not, in a few words. */
	public String connectionState() {
		if (demo) return "Connected";
		if (config.effectiveClientId().isEmpty()) return "Not set up";
		if (!oauth.loggedIn()) return oauth.loginInProgress() ? "Logging in..." : "Not logged in";
		SocketIo current = socket;
		return current != null && current.connected() ? "Connected" : "Connecting...";
	}

	public boolean connected() {
		SocketIo current = socket;
		return demo || current != null && current.connected();
	}

	/** The window opened: refresh the list and the open chat. Client thread. */
	public void panelOpened() {
		panelOpen = true;
		overlay.clearPopups();
		if (demo) return;
		exec.execute(() -> {
			fetchChats();
			refreshUnread();
			History open = viewed;
			if (open != null) loadHistory(open);
		});
	}

	public void panelClosed() {
		panelOpen = false;
	}

	/** Shows a chat in the window and marks it read. Client thread. */
	public void view(long chatId) {
		History open = viewed;
		if (open != null && open.chatId == chatId) return;
		History next = new History(chatId);
		viewedChat = chatId;
		viewed = next;
		if (demo) {
			next.messages = demoHistory(chatId);
			next.loading = false;
			return;
		}
		exec.execute(() -> {
			if (unread.remove(chatId) != null) publishChatList();
			loadHistory(next);
		});
	}

	public void openChatInBrowser(long chatId) {
		host.openUrl(chatUrl(chatId));
	}

	// ---- the Social Tap window: background thread ----

	private void publishChatList() {
		List<ChatInfo> rows = new ArrayList<>(baseChats.size());
		for (ChatInfo chat : baseChats) rows.add(chat.withUnread(unread.getOrDefault(chat.id(), 0)));
		chatList = List.copyOf(rows);
	}

	/** Unread counts from a notifications:get reply; chats it leaves out have none. */
	private void applyUnread(List<JsonObject> updates) {
		unread.clear();
		for (JsonObject update : updates) {
			long chatId = longOf(update, "chat_id");
			int count = (int) longOf(update, "unread_count");
			if (count > 0 && !(panelOpen && viewedChat == chatId)) unread.put(chatId, count);
		}
		publishChatList();
	}

	private void refreshUnread() {
		JsonObject request = new JsonObject();
		request.addProperty("since", Math.max(0, baseline));
		emit("notifications:get", request, envelope -> {
			if (SocketIo.statusOf(envelope) != 200 || !dataOf(envelope).isJsonObject()) return;
			JsonObject data = envelope.getAsJsonObject("data");
			List<JsonObject> updates = new ArrayList<>();
			if (data.has("updates") && data.get("updates").isJsonArray()) {
				for (JsonElement element : data.getAsJsonArray("updates")) {
					if (element.isJsonObject()) updates.add(element.getAsJsonObject());
				}
			}
			applyUnread(updates);
		});
	}

	/** Loads the newest messages (up to 178) of the chat on screen, then marks it read. */
	private void loadHistory(History history) {
		JsonObject request = new JsonObject();
		request.addProperty("chat_id", history.chatId);
		emit("messages:get", request, envelope -> {
			int status = SocketIo.statusOf(envelope);
			if (status != 200 || !dataOf(envelope).isJsonArray()) {
				history.loading = false;
				history.error = status == 0 ? "Not connected to Social Tap." : "Could not load messages: " + SocketIo.errorOf(envelope);
				return;
			}
			List<ChatMessage> messages = new ArrayList<>();
			long newest = 0;
			for (JsonElement element : envelope.getAsJsonArray("data")) {
				if (!element.isJsonObject()) continue;
				JsonObject message = element.getAsJsonObject();
				long id = longOf(message, "id");
				newest = Math.max(newest, id);
				shown.add(id);
				messages.add(toChatMessage(message, selfId != null && longOf(message, "sender_user_id") == selfId));
			}
			history.messages = List.copyOf(messages);
			history.error = "";
			history.loading = false;
			if (newest > 0) {
				lastSeen.merge(history.chatId, newest, Math::max);
				if (panelOpen && viewed == history) markRead(history.chatId, newest);
			}
		});
	}

	private void markRead(long chatId, long messageId) {
		if (unread.remove(chatId) != null) publishChatList();
		String token = oauth.cachedToken();
		if (token == null) return;
		JsonObject body = new JsonObject();
		body.addProperty("chat_id", chatId);
		body.addProperty("last_read_message_id", messageId);
		HttpRequest request = HttpRequest.newBuilder(URI.create(Constants.BASE_URL + "/api/chat/read"))
				.timeout(Duration.ofSeconds(10))
				.header("Authorization", "Bearer " + token)
				.header("Content-Type", "application/json")
				.header("Accept", "application/json")
				.header("User-Agent", Constants.USER_AGENT)
				.POST(HttpRequest.BodyPublishers.ofString(body.toString())).build();
		oauth.http().sendAsync(request, HttpResponse.BodyHandlers.discarding()).whenComplete((response, error) -> {
			if (error != null || response.statusCode() != 200) {
				Log.LOG.debug("Could not mark Social Tap chat {} read: {}", chatId, error != null ? error.toString() : "HTTP " + response.statusCode());
			}
		});
	}

	private ChatMessage toChatMessage(JsonObject message, boolean mine) {
		long id = longOf(message, "id");
		String username = mine ? stringOf(message, "username", "You") : stringOf(message, "username", "Someone");
		String time = stringOf(message, "timestamp", "");
		if (message.has("call") && message.get("call").isJsonObject()) {
			JsonObject call = message.getAsJsonObject("call");
			String outcome = stringOf(call, "outcome", "");
			long seconds = longOf(call, "duration_seconds");
			String text = switch (outcome) {
				case "completed" -> "Call ended · " + (seconds >= 60 ? seconds / 60 + "m " : "") + seconds % 60 + "s";
				case "missed" -> "Missed call";
				case "declined" -> "Declined call";
				case "failed" -> "Call failed";
				default -> "Call";
			};
			return new ChatMessage(id, username, text, time, mine, true);
		}
		String text = stringOf(message, "content", "");
		if (message.has("attachment") && message.get("attachment").isJsonObject()) {
			JsonObject attachment = message.getAsJsonObject("attachment");
			String file = stringOf(attachment, "filename", stringOf(attachment, "original_name", stringOf(attachment, "name", "a file")));
			String label = "[attachment: " + file + "]";
			text = text.isBlank() || text.equals("Shared an attachment") ? label : text + " " + label;
		}
		return new ChatMessage(id, username, text, time, mine, false);
	}

	// ---- calls you start ----

	/** Rings the other person in a two-person chat. Any thread. */
	public void startCall(long chatId, Consumer<String> feedback) {
		if (demo) {
			ChatInfo chat = chatList.stream().filter(c -> c.id() == chatId).findFirst().orElse(null);
			Overlay.ActiveCall call = new Overlay.ActiveCall("test", chatId, chat == null ? "Test Friend" : chat.name());
			call.outgoing = true;
			overlay.setActive(call);
			return;
		}
		exec.execute(() -> {
			if (overlay.active() != null || overlay.incoming() != null) {
				say(feedback, "You are already in a call.");
				return;
			}
			JsonObject request = new JsonObject();
			request.addProperty("chat_id", chatId);
			emit("call:start", request, ack -> {
				int status = SocketIo.statusOf(ack);
				if (status != 200 || !dataOf(ack).isJsonObject()) {
					String error = SocketIo.errorOf(ack);
					say(feedback, switch (status) {
						case 0 -> "Not connected to Social Tap right now.";
						case 409 -> "They are already in a call.";
						default -> "Could not start the call: " + error;
					});
					return;
				}
				JsonObject data = ack.getAsJsonObject("data");
				String callId = stringOf(data, "call_id", "");
				if (overlay.active() != null || callId.isEmpty()) {
					// Something else got there first; let this one go.
					if (!callId.isEmpty()) emit("call:end", callPayload(callId, "ended"), null);
					return;
				}
				relayRate = 16_000;
				frameSamples = 800;
				frameBytes = 404;
				if (data.has("relay_audio") && data.get("relay_audio").isJsonObject()) {
					JsonObject relay = data.getAsJsonObject("relay_audio");
					relayRate = (int) longOf(relay, "sample_rate");
					frameSamples = (int) longOf(relay, "frame_samples");
					frameBytes = (int) longOf(relay, "frame_bytes");
				}
				String name = stringOf(data, "username", "");
				if (name.isEmpty()) {
					name = chatList.stream().filter(c -> c.id() == chatId).map(ChatInfo::name).findFirst().orElse("Someone");
				}
				Overlay.ActiveCall call = new Overlay.ActiveCall(callId, chatId, name);
				call.outgoing = true;
				overlay.setActive(call);
			});
		});
	}

	/** They picked up the call we started: turn on the relay and the microphone. */
	private void callAccepted(JsonElement element) {
		Overlay.ActiveCall call = overlay.active();
		if (call == null || !call.outgoing || call.connected || !element.isJsonObject()) return;
		if (!call.callId.equals(stringOf(element.getAsJsonObject(), "call_id", ""))) return;
		emit("call:relay:start", callPayload(call.callId, null), relaying -> {
			if (overlay.active() != call) return;
			if (SocketIo.statusOf(relaying) != 200) failCall(call, SocketIo.errorOf(relaying));
			else startAudio(call);
		});
	}

	// ---- demo data for screenshots (-Dsocialtap.demo=panel) ----

	private void startDemoPanel() {
		demo = true;
		baseChats = List.of(
				new ChatInfo(1, "Test Friend", false, true, true, 0),
				new ChatInfo(2, "BrokenLH", false, true, false, 0),
				new ChatInfo(3, "Minecraft crew", true, false, false, 0),
				new ChatInfo(4, "Saved messages", false, false, false, 0));
		unread.put(2L, 3);
		unread.put(3L, 12);
		publishChatList();
		view(1);
	}

	private static List<ChatMessage> demoHistory(long chatId) {
		if (chatId != 1) return List.of(new ChatMessage(1, "BrokenLH", "yo are you on?", "14:02", false, false));
		return List.of(
				new ChatMessage(1, "Test Friend", "are you on the server?", "14:31", false, false),
				new ChatMessage(2, "Test Friend", "we're at spawn, come help with the farm", "14:31", false, false),
				new ChatMessage(3, "You", "yeah give me a sec", "14:32", true, false),
				new ChatMessage(4, "Test Friend", "Call ended · 4m 12s", "14:40", false, true),
				new ChatMessage(5, "Test Friend", "bring iron if you have any. we need like a whole stack for the hoppers and rails", "14:44", false, false));
	}

	public void answerRinging(Consumer<String> feedback) {
		if (!overlay.answer()) say(feedback, "No Social Tap call is ringing.");
	}

	public void declineRinging(Consumer<String> feedback) {
		if (!overlay.decline()) say(feedback, "No Social Tap call is ringing.");
	}

	// ---- overlay actions (client thread) ----

	@Override
	public void respond(Overlay.IncomingCall call) {
		exec.execute(() -> answer(call));
	}

	@Override
	public void decline(Overlay.IncomingCall call) {
		exec.execute(() -> {
			ringer.stop();
			if (isTest(call)) return;
			emit("call:end", callPayload(call.callId(), "declined"), null);
		});
	}

	@Override
	public void hangUp() {
		exec.execute(() -> {
			Overlay.ActiveCall call = overlay.active();
			if (call == null) return;
			emit("call:end", callPayload(call.callId, "ended"), null);
			endCallLocally();
		});
	}

	// ---- connection ----

	private void safeTick() {
		try {
			tick();
		} catch (Exception e) {
			Log.LOG.warn("Social Tap tick failed", e);
		}
		safeActivityTick();
	}

	private void safeActivityTick() {
		try {
			activityTick();
		} catch (Exception e) {
			Log.LOG.warn("Social Tap activity update failed", e);
		}
	}

	// ---- activity card ----

	private void activityTick() {
		if (config.effectiveClientId().isEmpty() || !oauth.loggedIn() || oauth.loginInProgress()) return;
		long now = System.currentTimeMillis();
		if (statusBusy || statusBlocked || now < statusRetryAtMs) return;

		String title = activityTitle;
		if (!config.activityStatus || title.isEmpty()) {
			if (cardLive) {
				cardRequest("DELETE", null, () -> {
					cardLive = false;
					publishedCard = "";
				});
			}
			return;
		}

		String subtitle = clean(activityDetail + " · " + playingFor(now - playingSinceMs), 256);
		JsonObject card = new JsonObject();
		card.addProperty("title", title);
		card.addProperty("subtitle", subtitle);
		card.addProperty("background_photo", config.effectiveActivityBackground());
		card.addProperty("visibility", config.activityVisibility);
		String wanted = card.toString();
		// The play time is part of the subtitle, so this also updates the card once a minute.
		if (wanted.equals(publishedCard) && now - publishedAtMs < CARD_REFRESH_MS) return;
		cardRequest("PUT", card, () -> {
			cardLive = true;
			publishedCard = wanted;
			publishedAtMs = System.currentTimeMillis();
		});
	}

	private void cardRequest(String method, JsonObject body, Runnable onSuccess) {
		String token;
		try {
			token = oauth.token();
		} catch (IOException e) {
			// The connection code reports logins that stopped working; just try again later.
			statusRetryAtMs = System.currentTimeMillis() + CARD_RETRY_MS;
			return;
		}
		statusBusy = true;
		oauth.http().sendAsync(cardHttp(method, body, token, 15), HttpResponse.BodyHandlers.ofString())
				.whenComplete((response, error) -> exec.execute(() -> {
					statusBusy = false;
					int code = response == null ? 0 : response.statusCode();
					if (code >= 200 && code < 300) {
						onSuccess.run();
					} else if (code == 403) {
						// This login was approved before the mod asked for the activity permission.
						statusBlocked = true;
						Log.LOG.warn("Social Tap login lacks the {} scope. Add it to the app in the developer dashboard if it is "
								+ "missing there, then run /socialtap login.", Constants.STATUS_SCOPE);
						notice("Show Minecraft on your profile", "Social Tap needs a new permission to show what you are playing. "
								+ "Run /socialtap login to allow it, or /socialtap activity false to turn this off.");
					} else {
						statusRetryAtMs = System.currentTimeMillis() + CARD_RETRY_MS;
						Log.LOG.warn("Social Tap activity {} failed: {}", method,
								response == null ? String.valueOf(error) : "HTTP " + code + " " + response.body());
					}
				}));
	}

	/** Takes the card down and waits for it, briefly. Safe from any thread. */
	private void clearCardNow() {
		if (!cardLive) return;
		String token = oauth.cachedToken();
		if (token == null) return; // it expires on its own within 15 minutes
		try {
			oauth.http().send(cardHttp("DELETE", null, token, 3), HttpResponse.BodyHandlers.discarding());
			cardLive = false;
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		} catch (Exception e) {
			Log.LOG.debug("Could not clear the Social Tap activity: {}", e.toString());
		}
	}

	private static HttpRequest cardHttp(String method, JsonObject body, String token, int timeoutSeconds) {
		HttpRequest.Builder request = HttpRequest.newBuilder(URI.create(Constants.BASE_URL + "/api/integration-status"))
				.timeout(Duration.ofSeconds(timeoutSeconds))
				.header("Authorization", "Bearer " + token)
				.header("Accept", "application/json")
				.header("User-Agent", Constants.USER_AGENT);
		if (body == null) return request.method(method, HttpRequest.BodyPublishers.noBody()).build();
		return request.header("Content-Type", "application/json")
				.method(method, HttpRequest.BodyPublishers.ofString(body.toString())).build();
	}

	/** "playing for 1h 5m". */
	static String playingFor(long elapsedMs) {
		long minutes = Math.max(0, elapsedMs) / 60_000;
		if (minutes < 1) return "just started playing";
		return "playing for " + (minutes >= 60 ? minutes / 60 + "h " : "") + minutes % 60 + "m";
	}

	/** Plain text the server accepts: no control characters, never blank, within its length limit. */
	private static String clean(String text, int max) {
		StringBuilder kept = new StringBuilder();
		if (text != null) {
			text.codePoints().filter(c -> !Character.isISOControl(c) && Character.getType(c) != Character.FORMAT)
					.forEach(kept::appendCodePoint);
		}
		String result = kept.toString().strip();
		if (result.length() > max) result = result.substring(0, max).strip();
		return result;
	}

	private void tick() {
		long now = System.currentTimeMillis();
		Overlay.IncomingCall ringing = overlay.incoming();
		if (ringing != null && now - ringing.atMs() > RING_TIMEOUT_MS) {
			overlay.setIncoming(null);
			ringing = null;
		}
		if (ringing == null) ringer.stop();
		Overlay.ActiveCall calling = overlay.active();
		if (calling != null && calling.outgoing && !calling.connected && now - calling.startedAtMs > OUTGOING_RING_MS) {
			// Social Tap stops ringing after 45 seconds; this only covers a lost "ended" event.
			if (!isTest(calling.callId)) emit("call:end", callPayload(calling.callId, "ended"), null);
			endCallLocally();
			notice("No answer", calling.username + " did not pick up.");
		}

		if (config.effectiveClientId().isEmpty() || !oauth.loggedIn() || oauth.loginInProgress()) return;
		SocketIo current = socket;
		if (current == null) {
			if (now >= nextConnectAtMs) connect();
			return;
		}
		boolean busy = ringing != null || overlay.active() != null;
		if (current.connected()) {
			if (!current.stale()) lastAliveMs = now;
			if (current.stale()) {
				disconnected(current, "no heartbeat");
			} else if (!busy && oauth.tokenAgeMs() > TOKEN_ROTATE_MS) {
				// Access tokens last 15 minutes and are checked on every event: move to a new one.
				connect();
			}
		} else if (now - connectStartedMs > 30_000) {
			disconnected(current, "connect timed out");
		}
	}

	private void connect() {
		closeSocket();
		if (!oauth.loggedIn()) return;
		String token;
		try {
			token = forceRefresh ? oauth.refresh() : oauth.token();
			forceRefresh = false;
		} catch (OAuth.LoggedOutException e) {
			Log.LOG.warn("{}", e.getMessage());
			notice("Social Tap logged out", "Your login expired or was revoked. Run /socialtap login to reconnect.");
			return;
		} catch (IOException e) {
			Log.LOG.warn("Could not refresh the Social Tap token: {}", e.toString());
			backOff();
			return;
		}

		SocketIo next = new SocketIo(exec);
		socket = next;
		connectStartedMs = System.currentTimeMillis();
		next.onConnect(() -> exec.execute(() -> {
			if (socket == next) connected(next);
		}));
		next.onDisconnect(reason -> exec.execute(() -> disconnected(next, reason)));
		next.on("chat:changed", (data, attachments) -> exec.execute(() -> chatChanged(data)));
		next.on("call:incoming", (data, attachments) -> exec.execute(() -> callIncoming(data)));
		next.on("call:claimed", (data, attachments) -> exec.execute(() -> callClaimed(next, data)));
		next.on("call:ended", (data, attachments) -> exec.execute(() -> callEnded(data)));
		next.on("call:accepted", (data, attachments) -> exec.execute(() -> callAccepted(data)));
		next.on("call:relay:start", (data, attachments) -> exec.execute(() -> relayStarted(data)));
		next.on("call:audio", (data, attachments) -> {
			CallAudio playing = audio;
			if (playing != null && !attachments.isEmpty()) playing.receive(attachments.get(0));
		});
		JsonObject auth = new JsonObject();
		auth.addProperty("access_token", token);
		next.connect(oauth.http(), Constants.BASE_URL, auth);
	}

	private void connected(SocketIo current) {
		failures = 0;
		Log.LOG.info("Connected to Social Tap");
		long now = System.currentTimeMillis();
		boolean longGap = lastAliveMs > 0 && now - lastAliveMs > LONG_GAP_MS;
		lastAliveMs = now;
		fetchChats();
		JsonObject request = new JsonObject();
		request.addProperty("since", Math.max(0, baseline));
		current.emit("notifications:get", request, envelope -> exec.execute(() -> {
			if (socket != current) return;
			List<JsonObject> updates = new ArrayList<>();
			long newest = 0;
			if (SocketIo.statusOf(envelope) == 200 && dataOf(envelope).isJsonObject()) {
				JsonObject data = envelope.getAsJsonObject("data");
				newest = longOf(data, "since");
				if (data.has("updates") && data.get("updates").isJsonArray()) {
					for (JsonElement element : data.getAsJsonArray("updates")) {
						if (!element.isJsonObject()) continue;
						JsonObject update = element.getAsJsonObject();
						updates.add(update);
						// The returned "since" can be 0 when nothing is unread, so take the newest
						// message ID from the unread and read cursors as well.
						newest = Math.max(newest, Math.max(longOf(update, "last_message_id"), longOf(update, "last_read_message_id")));
					}
				}
			}
			applyUnread(updates);
			if (baseline < 0 || longGap) {
				// Just logged in, or back after a long time away: everything up to here is old news.
				baseline = Math.max(baseline, newest);
				for (JsonObject update : updates) {
					long latest = longOf(update, "last_message_id");
					if (latest > 0) lastSeen.merge(longOf(update, "chat_id"), latest, Math::max);
				}
			} else {
				// A short reconnect: the server does not replay events, so catch up on what was missed.
				for (JsonObject update : updates) {
					if (longOf(update, "new_messages") > 0) queueChat(longOf(update, "chat_id"));
				}
			}
			primeChats();
		}));
	}

	/**
	 * Looks at every chat once, without showing anything, so each one has its own mark. Without
	 * this, the first event in a chat (a message of ours, a deleted message, a finished call) would
	 * hand back its history and the newest old message would pop up as if it had just arrived.
	 */
	private void primeChats() {
		for (long chatId : knownChats) {
			if (!lastSeen.containsKey(chatId) && !primeQueue.contains(chatId)) primeQueue.add(chatId);
		}
		if (config.showGlobalChat && !lastSeen.containsKey(0L) && !primeQueue.contains(0L)) primeQueue.add(0L);
		if (!priming) primeNext();
	}

	private void primeNext() {
		Long chatId = primeQueue.poll();
		while (chatId != null && lastSeen.containsKey(chatId)) chatId = primeQueue.poll();
		if (chatId == null) {
			priming = false;
			return;
		}
		priming = true;
		long chat = chatId;
		long floor = Math.max(0, baseline);
		JsonObject request = new JsonObject();
		request.addProperty("chat_id", chat);
		if (floor > 0) request.addProperty("last_id", floor);
		SocketIo owner = socket;
		emit("messages:get", request, envelope -> {
			if (socket != owner) return; // a newer connection has started its own pass
			int status = SocketIo.statusOf(envelope);
			if (status == 200 && dataOf(envelope).isJsonArray()) {
				long newest = floor;
				for (JsonElement element : envelope.getAsJsonArray("data")) {
					if (element.isJsonObject()) newest = Math.max(newest, longOf(element.getAsJsonObject(), "id"));
				}
				lastSeen.merge(chat, newest, Math::max);
			}
			if (status == 0) {
				// Not connected, or no answer: the next connection starts this again.
				primeQueue.clear();
				priming = false;
				return;
			}
			primeNext();
		});
	}

	private void disconnected(SocketIo current, String reason) {
		if (socket != current) return;
		Log.LOG.info("Social Tap disconnected: {}", reason);
		if (reason.startsWith("connect_error")) forceRefresh = true;
		closeSocket();
		backOff();
	}

	private void backOff() {
		failures = Math.min(failures + 1, 5);
		nextConnectAtMs = System.currentTimeMillis() + Math.min(60_000, 2_000L << failures);
	}

	private void closeSocket() {
		SocketIo current = socket;
		socket = null;
		if (current != null) current.close();
		primeQueue.clear();
		priming = false;
		// A call cannot outlive the socket that owns it.
		ringer.stop();
		overlay.setIncoming(null);
		endCallLocally();
	}

	private void emit(String event, JsonObject data, Consumer<JsonObject> ack) {
		SocketIo current = socket;
		if (current == null) {
			if (ack != null) {
				JsonObject envelope = new JsonObject();
				envelope.addProperty("status", 0);
				envelope.addProperty("error", "not connected");
				ack.accept(envelope);
			}
			return;
		}
		current.emit(event, data, ack == null ? null : envelope -> exec.execute(() -> ack.accept(envelope)));
	}

	// ---- messages ----

	private void chatChanged(JsonElement data) {
		long chatId = data != null && data.isJsonObject() ? longOf(data.getAsJsonObject(), "chat_id") : 0;
		if (chatId > 0 && !knownChats.contains(chatId)) fetchChats();
		History open = viewed;
		if (panelOpen && open != null && open.chatId == chatId) {
			// The chat on screen: reload it, which also picks up edits and deletions.
			loadHistory(open);
			return;
		}
		queueChat(chatId);
	}

	private void queueChat(long chatId) {
		if (chatId == 0 && !config.showGlobalChat) return;
		boolean first = pendingChats.isEmpty();
		pendingChats.add(chatId);
		// Several events for one send (message + read cursor) collapse into one fetch.
		if (first) exec.schedule(this::flushChats, 250, TimeUnit.MILLISECONDS);
	}

	private void flushChats() {
		List<Long> chats = new ArrayList<>(pendingChats);
		pendingChats.clear();
		for (long chatId : chats) fetchNewMessages(chatId);
	}

	private void fetchNewMessages(long chatId) {
		// Both taken now, not when the answer arrives: a message that came in between is still new.
		boolean marked = lastSeen.containsKey(chatId);
		long last = Math.max(0, lastSeen.getOrDefault(chatId, baseline));
		JsonObject request = new JsonObject();
		request.addProperty("chat_id", chatId);
		if (last > 0) request.addProperty("last_id", last);
		emit("messages:get", request, envelope -> {
			int status = SocketIo.statusOf(envelope);
			if (status == 401) {
				forceRefresh = true;
				connect();
				return;
			}
			if (status != 200 || !dataOf(envelope).isJsonArray()) {
				if (status != 0) Log.LOG.debug("messages:get failed: {}", SocketIo.errorOf(envelope));
				return;
			}
			List<JsonObject> fresh = new ArrayList<>();
			long newest = last;
			long serverNow = System.currentTimeMillis() + clockOffsetMs;
			for (JsonElement element : envelope.getAsJsonArray("data")) {
				JsonObject message = element.getAsJsonObject();
				long id = longOf(message, "id");
				newest = Math.max(newest, id);
				if (id <= last || shown.contains(id)) continue;
				if (message.has("call") && !message.get("call").isJsonNull()) continue; // call history
				if (selfId != null && longOf(message, "sender_user_id") == selfId) continue;
				// A chat with no mark of its own may hand back history: keep only what was just sent.
				if (!marked && !justSent(message, serverNow)) continue;
				fresh.add(message);
			}
			lastSeen.merge(chatId, newest, Math::max);
			if (fresh.isEmpty()) return;
			if (selfId != null) {
				showMessages(chatId, fresh, fresh.size());
			} else {
				// We could not work out which account is ours, so ask the server how many of these
				// are from other people (its unread count leaves out our own messages).
				List<JsonObject> candidates = fresh;
				JsonObject counts = new JsonObject();
				counts.addProperty("since", Math.max(0, last));
				emit("notifications:get", counts, reply -> showMessages(chatId, candidates, unreadFor(chatId, reply)));
			}
		});
	}

	private static int unreadFor(long chatId, JsonObject envelope) {
		if (SocketIo.statusOf(envelope) != 200 || !dataOf(envelope).isJsonObject()) return 0;
		JsonObject data = envelope.getAsJsonObject("data");
		if (!data.has("updates")) return 0;
		for (JsonElement element : data.getAsJsonArray("updates")) {
			JsonObject update = element.getAsJsonObject();
			if (longOf(update, "chat_id") == chatId) return (int) longOf(update, "new_messages");
		}
		return 0;
	}

	/** True when the message's own timestamp says it was sent in the last few minutes. */
	private static boolean justSent(JsonObject message, long serverNow) {
		String stamp = stringOf(message, "timestamp_iso", "");
		long sentAt;
		try {
			sentAt = OffsetDateTime.parse(stamp).toInstant().toEpochMilli();
		} catch (DateTimeParseException e) {
			try {
				sentAt = LocalDateTime.parse(stamp).toInstant(ZoneOffset.UTC).toEpochMilli();
			} catch (DateTimeParseException unreadable) {
				return false;
			}
		}
		return serverNow - sentAt <= JUST_SENT_MS;
	}

	private void showMessages(long chatId, List<JsonObject> messages, int count) {
		int show = Math.min(Math.min(count, messages.size()), MAX_POPUPS_PER_FETCH);
		if (shown.size() > 2000) shown.clear();
		for (JsonObject message : messages) shown.add(longOf(message, "id"));
		int fromOthers = Math.min(count, messages.size());
		if (fromOthers > 0 && !(panelOpen && viewedChat == chatId)) {
			unread.merge(chatId, fromOthers, Integer::sum);
			publishChatList();
		}
		// With the Social Tap window open, the chat list's unread counts say it instead.
		if (panelOpen) return;
		for (JsonObject message : messages.subList(messages.size() - show, messages.size())) {
			String sender = stringOf(message, "username", "Someone");
			String where = chatId == 0 ? " in Global Chat" : groupNames.containsKey(chatId) ? " in " + groupNames.get(chatId) : "";
			String body = stringOf(message, "content", "");
			if (body.isBlank()) body = "Sent an attachment";
			overlay.show(new Overlay.Popup(sender + where, body, () -> host.openUrl(chatUrl(chatId)), popupMs()));
		}
	}

	/** Loads chat names and works out our own user ID (the one member every chat has in common). */
	private void fetchChats() {
		try {
			HttpRequest request = HttpRequest.newBuilder(URI.create(Constants.BASE_URL + "/api/chats"))
					.timeout(Duration.ofSeconds(10))
					.header("Authorization", "Bearer " + oauth.token())
					.header("Accept", "application/json")
					.header("User-Agent", Constants.USER_AGENT)
					.GET().build();
			HttpResponse<String> response = oauth.http().send(request, HttpResponse.BodyHandlers.ofString());
			response.headers().firstValue("date").ifPresent(date -> {
				try {
					clockOffsetMs = ZonedDateTime.parse(date, DateTimeFormatter.RFC_1123_DATE_TIME).toInstant().toEpochMilli()
							- System.currentTimeMillis();
				} catch (DateTimeParseException e) {
					// Keep trusting our own clock.
				}
			});
			if (response.statusCode() != 200) return;
			JsonArray chats = JsonParser.parseString(response.body()).getAsJsonArray();
			Set<Long> common = null;
			Map<Long, List<JsonObject>> twoPerson = new HashMap<>();
			for (JsonElement element : chats) {
				JsonObject chat = element.getAsJsonObject();
				long id = longOf(chat, "id");
				knownChats.add(id);
				boolean isPrivate = chat.has("is_private") && chat.get("is_private").getAsBoolean();
				if (!isPrivate) groupNames.put(id, stringOf(chat, "name", "a group"));
				Set<Long> members = new HashSet<>();
				List<JsonObject> people = new ArrayList<>();
				if (chat.has("participants") && chat.get("participants").isJsonArray()) {
					for (JsonElement participant : chat.getAsJsonArray("participants")) {
						if (!participant.isJsonObject()) continue;
						members.add(longOf(participant.getAsJsonObject(), "id"));
						people.add(participant.getAsJsonObject());
					}
				}
				if (isPrivate && people.size() == 2) twoPerson.put(id, people);
				if (members.isEmpty()) continue;
				if (common == null) common = members;
				else common.retainAll(members);
			}
			if (common != null && common.size() == 1) selfId = common.iterator().next();

			// The window's chat list, in the order Social Tap keeps it.
			List<ChatInfo> rows = new ArrayList<>();
			if (config.showGlobalChat) rows.add(new ChatInfo(0, "Global Chat", true, false, false, 0));
			for (JsonElement element : chats) {
				JsonObject chat = element.getAsJsonObject();
				long id = longOf(chat, "id");
				boolean isPrivate = chat.has("is_private") && chat.get("is_private").getAsBoolean();
				List<JsonObject> others = new ArrayList<>();
				int people = 0;
				if (chat.has("participants") && chat.get("participants").isJsonArray()) {
					for (JsonElement participant : chat.getAsJsonArray("participants")) {
						if (!participant.isJsonObject()) continue;
						people++;
						if (selfId == null || longOf(participant.getAsJsonObject(), "id") != selfId) others.add(participant.getAsJsonObject());
					}
				}
				String name;
				boolean online = false;
				if (isPrivate && people == 1) {
					name = "Saved messages";
				} else if (isPrivate && people == 2) {
					List<String> names = new ArrayList<>();
					for (JsonObject other : others) {
						names.add(stringOf(other, "username", "Someone"));
						online |= other.has("online") && other.get("online").isJsonPrimitive() && other.get("online").getAsBoolean();
					}
					name = String.join(", ", names);
				} else {
					name = stringOf(chat, "name", "Group");
				}
				rows.add(new ChatInfo(id, name, !isPrivate, people == 2, online, 0));
			}
			baseChats = List.copyOf(rows);
			publishChatList();

			// The other person in each one-to-one chat. Without a known own ID both names are kept,
			// which only matters if you /respond to yourself.
			Map<String, DirectChat> direct = new HashMap<>();
			Set<String> names = new java.util.TreeSet<>(String.CASE_INSENSITIVE_ORDER);
			for (Map.Entry<Long, List<JsonObject>> entry : twoPerson.entrySet()) {
				for (JsonObject person : entry.getValue()) {
					if (selfId != null && longOf(person, "id") == selfId) continue;
					String username = stringOf(person, "username", "");
					if (username.isBlank()) continue;
					DirectChat chat = new DirectChat(entry.getKey(), username);
					direct.putIfAbsent(nameKey(username), chat);
					String profile = stringOf(person, "profile_username", "");
					if (!profile.isBlank()) direct.putIfAbsent(nameKey(profile), chat);
					names.add(username);
				}
			}
			directChats = Map.copyOf(direct);
			directNames = List.copyOf(names);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		} catch (Exception e) {
			Log.LOG.debug("Could not load Social Tap chats: {}", e.toString());
		}
	}

	// ---- calls ----

	private void callIncoming(JsonElement element) {
		if (!element.isJsonObject() || overlay.active() != null) return;
		JsonObject data = element.getAsJsonObject();
		int rate = 16_000;
		int samples = 800;
		int bytes = 404;
		if (data.has("relay_audio") && data.get("relay_audio").isJsonObject()) {
			JsonObject relay = data.getAsJsonObject("relay_audio");
			rate = (int) longOf(relay, "sample_rate");
			samples = (int) longOf(relay, "frame_samples");
			bytes = (int) longOf(relay, "frame_bytes");
		}
		overlay.setIncoming(new Overlay.IncomingCall(stringOf(data, "call_id", ""), longOf(data, "chat_id"),
				stringOf(data, "username", "Someone"), System.currentTimeMillis(), rate, samples, bytes));
		if (config.ringtone) ringer.start();
	}

	private void callClaimed(SocketIo current, JsonElement element) {
		if (!element.isJsonObject()) return;
		JsonObject data = element.getAsJsonObject();
		Overlay.IncomingCall ringing = overlay.incoming();
		// Picked up on another device or tab.
		if (ringing != null && ringing.callId().equals(stringOf(data, "call_id", ""))
				&& !current.sid().equals(stringOf(data, "sid", ""))) {
			overlay.setIncoming(null);
			ringer.stop();
		}
	}

	private void callEnded(JsonElement element) {
		if (!element.isJsonObject()) return;
		JsonObject data = element.getAsJsonObject();
		String callId = stringOf(data, "call_id", "");
		Overlay.IncomingCall ringing = overlay.incoming();
		if (ringing != null && ringing.callId().equals(callId)) {
			overlay.setIncoming(null);
			ringer.stop();
			long chatId = ringing.chatId();
			overlay.show(new Overlay.Popup("Missed call", ringing.username() + " called you on Social Tap.",
					() -> host.openUrl(chatUrl(chatId)), popupMs()));
		}
		Overlay.ActiveCall call = overlay.active();
		if (call != null && call.callId.equals(callId)) {
			endCallLocally();
			if (call.outgoing && !call.connected) {
				String reason = stringOf(data, "reason", "");
				if (reason.equals("declined")) notice("Call declined", call.username + " declined the call.");
				else if (reason.equals("no_answer")) notice("No answer", call.username + " did not pick up.");
			}
		}
	}

	private void answer(Overlay.IncomingCall incoming) {
		ringer.stop();
		if (isTest(incoming)) {
			notice("Test call answered", "A real call would now connect your microphone and speakers.");
			return;
		}
		relayRate = incoming.relayRate();
		frameSamples = incoming.frameSamples();
		frameBytes = incoming.frameBytes();
		Overlay.ActiveCall call = new Overlay.ActiveCall(incoming.callId(), incoming.chatId(), incoming.username());
		overlay.setActive(call);
		// Claim the call first, then ask the server to relay audio, then open the microphone.
		emit("call:accept", callPayload(call.callId, null), accepted -> {
			if (overlay.active() != call) return;
			if (SocketIo.statusOf(accepted) != 200) {
				failCall(call, SocketIo.errorOf(accepted));
				return;
			}
			if (dataOf(accepted).isJsonObject() && accepted.getAsJsonObject("data").has("relay_audio")
					&& accepted.getAsJsonObject("data").get("relay_audio").isJsonObject()) {
				JsonObject relay = accepted.getAsJsonObject("data").getAsJsonObject("relay_audio");
				relayRate = (int) longOf(relay, "sample_rate");
				frameSamples = (int) longOf(relay, "frame_samples");
				frameBytes = (int) longOf(relay, "frame_bytes");
			}
			emit("call:relay:start", callPayload(call.callId, null), relaying -> {
				if (overlay.active() != call) return;
				if (SocketIo.statusOf(relaying) != 200) failCall(call, SocketIo.errorOf(relaying));
				else startAudio(call);
			});
		});
	}

	private void relayStarted(JsonElement element) {
		Overlay.ActiveCall call = overlay.active();
		if (call != null && element.isJsonObject() && call.callId.equals(stringOf(element.getAsJsonObject(), "call_id", ""))) {
			startAudio(call);
		}
	}

	private void startAudio(Overlay.ActiveCall call) {
		if (audio != null) return;
		try {
			CallAudio started = new CallAudio(relayRate, frameSamples, frameBytes, frame -> {
				SocketIo current = socket;
				if (current != null) current.emitBinary("call:audio", callPayload(call.callId, null), "frame", frame);
			});
			started.start();
			audio = started;
		} catch (IllegalArgumentException e) {
			failCall(call, e.getMessage());
			return;
		}
		call.connectedAtMs = System.currentTimeMillis();
		call.connected = true;
		emit("call:connected", callPayload(call.callId, null), null);
	}

	private void failCall(Overlay.ActiveCall call, String reason) {
		Log.LOG.warn("Social Tap call failed: {}", reason);
		emit("call:end", callPayload(call.callId, "connection_issue"), null);
		endCallLocally();
		notice("Call failed", reason);
	}

	private void endCallLocally() {
		CallAudio playing = audio;
		audio = null;
		if (playing != null) playing.stop();
		overlay.setActive(null);
	}

	// ---- helpers ----

	private static boolean isTest(Overlay.IncomingCall call) {
		return isTest(call.callId());
	}

	private static boolean isTest(String callId) {
		return "test".equals(callId);
	}

	private static JsonObject callPayload(String callId, String reason) {
		JsonObject payload = new JsonObject();
		payload.addProperty("call_id", callId);
		if (reason != null) payload.addProperty("reason", reason);
		return payload;
	}

	private static String nameKey(String name) {
		return name == null ? "" : name.strip().toLowerCase(java.util.Locale.ROOT);
	}

	private static String chatUrl(long chatId) {
		return chatId > 0 ? Constants.BASE_URL + "/chat/" + chatId : Constants.BASE_URL + "/";
	}

	private void notice(String title, String body) {
		overlay.show(new Overlay.Popup(title, body, null, popupMs()));
	}

	/** How long a popup stays: 10 seconds in the middle of the screen, 5 in the quiet corner. */
	private long popupMs() {
		return (config.obnoxious ? config.messageSeconds : config.quietMessageSeconds) * 1000L;
	}

	private static void say(Consumer<String> feedback, String message) {
		if (feedback != null) feedback.accept(message);
	}

	private static JsonElement dataOf(JsonObject envelope) {
		JsonElement data = envelope.get("data");
		return data == null ? com.google.gson.JsonNull.INSTANCE : data;
	}

	private static long longOf(JsonObject object, String key) {
		JsonElement value = object.get(key);
		try {
			return value == null || value.isJsonNull() ? 0 : value.getAsLong();
		} catch (Exception e) {
			return 0;
		}
	}

	private static String stringOf(JsonObject object, String key, String fallback) {
		JsonElement value = object.get(key);
		return value == null || !value.isJsonPrimitive() ? fallback : value.getAsString();
	}
}
