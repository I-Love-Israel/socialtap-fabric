package social.socialtap.core;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.Duration;
import java.util.Base64;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.sun.net.httpserver.HttpServer;

/**
 * Social Tap OAuth for normal accounts: authorization code + PKCE S256, no client secret.
 * Access tokens last 15 minutes; refresh tokens rotate on every use, so each new pair is saved.
 */
public final class OAuth {
	/** The saved login no longer works (revoked, expired or rotated elsewhere). */
	public static final class LoggedOutException extends IOException {
		public LoggedOutException(String message) {
			super(message);
		}
	}

	private final Config config;
	private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();
	private String accessToken;
	private long accessExpiresAtMs;
	private long accessIssuedAtMs;
	private volatile boolean loginInProgress;

	public OAuth(Config config) {
		this.config = config;
	}

	public HttpClient http() {
		return http;
	}

	public boolean loggedIn() {
		return !config.refreshToken.isEmpty();
	}

	public boolean loginInProgress() {
		return loginInProgress;
	}

	public synchronized long tokenAgeMs() {
		return accessToken == null ? Long.MAX_VALUE : System.currentTimeMillis() - accessIssuedAtMs;
	}

	/** A valid access token, refreshed when it is close to expiring. */
	public synchronized String token() throws IOException {
		if (accessToken != null && System.currentTimeMillis() < accessExpiresAtMs - 60_000) return accessToken;
		return refresh();
	}

	public synchronized String refresh() throws IOException {
		if (!loggedIn()) throw new LoggedOutException("Not logged in");
		Map<String, String> form = new LinkedHashMap<>();
		form.put("grant_type", "refresh_token");
		form.put("client_id", config.effectiveClientId());
		form.put("refresh_token", config.refreshToken);
		HttpResponse<String> response = postForm("/api/oauth/token", form);
		if (response.statusCode() == 200) {
			storeTokens(response.body());
			return accessToken;
		}
		if (response.statusCode() == 400 || response.statusCode() == 401) {
			clear();
			throw new LoggedOutException("Social Tap login expired (" + describe(response) + ")");
		}
		throw new IOException("Token refresh failed: HTTP " + response.statusCode());
	}

	public synchronized void logout() {
		if (loggedIn()) {
			try {
				Map<String, String> form = new LinkedHashMap<>();
				form.put("client_id", config.effectiveClientId());
				form.put("token", config.refreshToken);
				postForm("/api/oauth/revoke", form);
			} catch (IOException e) {
				Log.LOG.warn("Could not revoke the Social Tap token: {}", e.toString());
			}
		}
		clear();
	}

	private void clear() {
		accessToken = null;
		accessExpiresAtMs = 0;
		config.refreshToken = "";
		config.save();
	}

	/**
	 * Runs the browser login and blocks until it finishes (up to five minutes).
	 * The player approves the app on socialtap.social; this mod never sees their password.
	 */
	public void login(Host host) throws IOException {
		String clientId = config.effectiveClientId();
		if (clientId.isEmpty()) throw new IOException("No Social Tap client ID is set");
		if (loginInProgress) throw new IOException("A Social Tap login is already open in your browser");
		loginInProgress = true;
		HttpServer server = null;
		try {
			String verifier = randomToken();
			String state = randomToken();
			String challenge = base64Url(MessageDigest.getInstance("SHA-256").digest(verifier.getBytes(StandardCharsets.US_ASCII)));

			CompletableFuture<String> outcome = new CompletableFuture<>();
			server = HttpServer.create(new InetSocketAddress(InetAddress.getByName("127.0.0.1"), Constants.CALLBACK_PORT), 0);
			server.createContext("/callback", exchange -> {
				Map<String, String> query = parseQuery(exchange.getRequestURI().getRawQuery());
				String error = null;
				if (!state.equals(query.get("state"))) {
					error = "This login link did not come from your Minecraft session.";
				} else if (query.containsKey("error")) {
					error = "Social Tap said: " + query.get("error");
					outcome.complete(error);
				} else if (!query.containsKey("code")) {
					error = "Social Tap did not send a login code.";
				} else {
					try {
						Map<String, String> form = new LinkedHashMap<>();
						form.put("grant_type", "authorization_code");
						form.put("client_id", clientId);
						form.put("code", query.get("code"));
						form.put("redirect_uri", Constants.REDIRECT_URI);
						form.put("code_verifier", verifier);
						HttpResponse<String> response = postForm("/api/oauth/token", form);
						if (response.statusCode() == 200) {
							synchronized (OAuth.this) {
								storeTokens(response.body());
							}
							outcome.complete("");
						} else {
							error = "Social Tap refused the login (" + describe(response) + ").";
							outcome.complete(error);
						}
					} catch (Exception e) {
						error = "Could not reach Social Tap: " + e.getMessage();
						outcome.complete(error);
					}
				}
				String title = error == null ? "Social Tap is connected to Minecraft" : "Social Tap login failed";
				String detail = error == null ? "You can close this tab and go back to the game." : escape(error);
				byte[] page = ("<!doctype html><meta charset=utf-8><title>Social Tap</title>"
						+ "<body style=\"font-family:sans-serif;background:#14141c;color:#fff;text-align:center;padding-top:20vh\">"
						+ "<h1>" + title + "</h1><p>" + detail + "</p></body>").getBytes(StandardCharsets.UTF_8);
				exchange.getResponseHeaders().set("Content-Type", "text/html; charset=utf-8");
				exchange.getResponseHeaders().set("Cache-Control", "no-store");
				exchange.sendResponseHeaders(error == null ? 200 : 400, page.length);
				try (OutputStream body = exchange.getResponseBody()) {
					body.write(page);
				}
			});
			server.start();

			host.openUrl(Constants.BASE_URL + "/api/oauth/authorize"
					+ "?response_type=code"
					+ "&client_id=" + encode(clientId)
					+ "&redirect_uri=" + encode(Constants.REDIRECT_URI)
					+ "&scope=" + encode(Constants.SCOPES)
					+ "&state=" + state
					+ "&code_challenge=" + challenge
					+ "&code_challenge_method=S256");

			String error;
			try {
				error = outcome.get(5, TimeUnit.MINUTES);
			} catch (TimeoutException e) {
				throw new IOException("Login timed out. Run /socialtap login to try again.");
			}
			if (!error.isEmpty()) throw new IOException(error);
		} catch (IOException e) {
			throw e;
		} catch (Exception e) {
			throw new IOException(e.getMessage() == null ? e.toString() : e.getMessage(), e);
		} finally {
			if (server != null) server.stop(1);
			loginInProgress = false;
		}
	}

	private void storeTokens(String json) {
		JsonObject body = JsonParser.parseString(json).getAsJsonObject();
		accessToken = body.get("access_token").getAsString();
		long expiresIn = body.has("expires_in") ? body.get("expires_in").getAsLong() : 900;
		accessIssuedAtMs = System.currentTimeMillis();
		accessExpiresAtMs = accessIssuedAtMs + expiresIn * 1000;
		if (body.has("refresh_token") && !body.get("refresh_token").isJsonNull()) {
			config.refreshToken = body.get("refresh_token").getAsString();
			config.save();
		}
	}

	private HttpResponse<String> postForm(String path, Map<String, String> form) throws IOException {
		StringBuilder body = new StringBuilder();
		for (Map.Entry<String, String> entry : form.entrySet()) {
			if (body.length() > 0) body.append('&');
			body.append(encode(entry.getKey())).append('=').append(encode(entry.getValue()));
		}
		HttpRequest request = HttpRequest.newBuilder(URI.create(Constants.BASE_URL + path))
				.timeout(Duration.ofSeconds(20))
				.header("Content-Type", "application/x-www-form-urlencoded")
				.header("Accept", "application/json")
				.header("User-Agent", Constants.USER_AGENT)
				.POST(HttpRequest.BodyPublishers.ofString(body.toString()))
				.build();
		try {
			return http.send(request, HttpResponse.BodyHandlers.ofString());
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
			throw new IOException("Interrupted", e);
		}
	}

	private static String describe(HttpResponse<String> response) {
		try {
			JsonObject body = JsonParser.parseString(response.body()).getAsJsonObject();
			if (body.has("error_description")) return body.get("error_description").getAsString();
			if (body.has("error")) return body.get("error").getAsString();
		} catch (Exception ignored) {
			// Not JSON: fall through to the status code.
		}
		return "HTTP " + response.statusCode();
	}

	private static Map<String, String> parseQuery(String raw) {
		Map<String, String> query = new HashMap<>();
		if (raw == null) return query;
		for (String pair : raw.split("&")) {
			int equals = pair.indexOf('=');
			if (equals <= 0) continue;
			query.put(URLDecoder.decode(pair.substring(0, equals), StandardCharsets.UTF_8),
					URLDecoder.decode(pair.substring(equals + 1), StandardCharsets.UTF_8));
		}
		return query;
	}

	/** 32 random bytes as 43 URL-safe characters: valid as both the state and the PKCE verifier. */
	private static String randomToken() {
		byte[] bytes = new byte[32];
		new SecureRandom().nextBytes(bytes);
		return base64Url(bytes);
	}

	private static String base64Url(byte[] bytes) {
		return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
	}

	private static String encode(String value) {
		return URLEncoder.encode(value, StandardCharsets.UTF_8);
	}

	private static String escape(String text) {
		return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
	}
}
