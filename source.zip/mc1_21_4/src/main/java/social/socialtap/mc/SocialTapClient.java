package social.socialtap.mc;

import java.util.Locale;
import java.util.function.Consumer;

import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;

import org.lwjgl.glfw.GLFW;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import social.socialtap.core.ChatPanel;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents;
import net.fabricmc.fabric.api.event.client.player.ClientPreAttackCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.network.chat.Component;
import social.socialtap.core.Overlay;
import social.socialtap.core.SocialTapService;

/** Minecraft 1.21.4 wiring: where the overlay is drawn and where its clicks come from. */
public class SocialTapClient implements ClientModInitializer {
	/** Above every HUD layer, tooltip and item in this version's depth-sorted GUI. */
	private static final float OVERLAY_Z = 5000f;

	@Override
	public void onInitializeClient() {
		SocialTapService service = new SocialTapService(FabricLoader.getInstance().getConfigDir(),
				url -> Util.getPlatform().openUri(url));
		Overlay overlay = service.overlay();

		// The Social Tap window: chats, messages and calls. Opened with ` (rebind it in Controls)
		// or /socialtap open.
		ChatPanel panel = new ChatPanel(service, () -> Minecraft.getInstance().keyboardHandler.getClipboard());
		KeyMapping openKey = KeyBindingHelper.registerKeyBinding(new KeyMapping("key.socialtap.open", InputConstants.Type.KEYSYM,
				GLFW.GLFW_KEY_GRAVE_ACCENT, "key.categories.socialtap"));
		boolean[] openRequested = {false}; // by /socialtap, once its chat box has closed
		// Development aid: -Dsocialtap.demo=panel opens the window over the title screen.
		int[] demoOpenIn = {System.getProperty("socialtap.demo", "").contains("panel") ? 60 : -1};
		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			boolean wanted = false;
			while (openKey.consumeClick()) wanted = true;
			if (demoOpenIn[0] > 0 && client.getOverlay() == null && client.screen != null && --demoOpenIn[0] == 0) wanted = true;
			if (openRequested[0] && client.screen == null) {
				openRequested[0] = false;
				wanted = true;
			}
			if (wanted && !(client.screen instanceof SocialTapScreen)) client.setScreen(new SocialTapScreen(panel, openKey));
		});

		// In the world with no menu open: drawn over the rest of the HUD.
		HudRenderCallback.EVENT.register((graphics, delta) -> {
			if (Minecraft.getInstance().screen == null) render(overlay, graphics);
		});

		// With any menu open (pause, chat, inventory, title screen): drawn over it, and clickable.
		ScreenEvents.AFTER_INIT.register((client, screen, width, height) -> {
			ScreenEvents.afterRender(screen).register((current, graphics, mouseX, mouseY, delta) -> render(overlay, graphics));
			ScreenMouseEvents.allowMouseClick(screen).register((current, mouseX, mouseY, button) ->
					!(button == 0 && overlay.screenClick(mouseX, mouseY)));
		});

		// A new left click in the world lands on whatever is in the middle of the screen.
		ClientPreAttackCallback.EVENT.register((client, player, clickCount) -> clickCount > 0 && overlay.attackClick());

		// /respond <username> <message>: reply in your one-to-one Social Tap chat with that person.
		ClientCommandRegistrationCallback.EVENT.register((dispatcher, context) -> dispatcher.register(
				ClientCommandManager.literal("respond")
						.then(ClientCommandManager.argument("username", StringArgumentType.string())
								.suggests((command, builder) -> {
									String typed = builder.getRemainingLowerCase();
									for (String name : service.directChatNames()) {
										String option = StringArgumentType.escapeIfRequired(name);
										if (option.toLowerCase(Locale.ROOT).startsWith(typed) || name.toLowerCase(Locale.ROOT).startsWith(typed)) {
											builder.suggest(option);
										}
									}
									return builder.buildFuture();
								})
								.then(ClientCommandManager.argument("message", StringArgumentType.greedyString()).executes(command -> {
									service.sendMessage(StringArgumentType.getString(command, "username"),
											StringArgumentType.getString(command, "message"), feedback(command.getSource()));
									return 1;
								})))));

		ClientCommandRegistrationCallback.EVENT.register((dispatcher, context) -> dispatcher.register(
				ClientCommandManager.literal("socialtap")
						.executes(command -> {
							openRequested[0] = true; // opens once the chat box has closed
							return 1;
						})
						.then(ClientCommandManager.literal("open").executes(command -> {
							openRequested[0] = true;
							return 1;
						}))
						.then(ClientCommandManager.literal("login").executes(command -> {
							service.login(feedback(command.getSource()));
							return 1;
						}))
						.then(ClientCommandManager.literal("logout").executes(command -> {
							service.logout(feedback(command.getSource()));
							return 1;
						}))
						.then(ClientCommandManager.literal("status").executes(command -> {
							service.status(feedback(command.getSource()));
							return 1;
						}))
						.then(ClientCommandManager.literal("hangup").executes(command -> {
							service.hangUp();
							return 1;
						}))
						.then(ClientCommandManager.literal("answer").executes(command -> {
							service.answerRinging(feedback(command.getSource()));
							return 1;
						}))
						.then(ClientCommandManager.literal("decline").executes(command -> {
							service.declineRinging(feedback(command.getSource()));
							return 1;
						}))
						.then(ClientCommandManager.literal("obnoxious")
								.executes(command -> {
									service.obnoxious(null, feedback(command.getSource()));
									return 1;
								})
								.then(ClientCommandManager.argument("enabled", BoolArgumentType.bool()).executes(command -> {
									service.obnoxious(BoolArgumentType.getBool(command, "enabled"), feedback(command.getSource()));
									return 1;
								})))
						.then(ClientCommandManager.literal("activity")
								.executes(command -> {
									service.activity(null, feedback(command.getSource()));
									return 1;
								})
								.then(ClientCommandManager.argument("enabled", BoolArgumentType.bool()).executes(command -> {
									service.activity(BoolArgumentType.getBool(command, "enabled"), feedback(command.getSource()));
									return 1;
								})))
						.then(ClientCommandManager.literal("test")
								.then(ClientCommandManager.literal("call").executes(command -> {
									service.testCall();
									return 1;
								}))
								.then(ClientCommandManager.literal("message").executes(command -> {
									service.testMessage();
									return 1;
								})))));

		ClientLifecycleEvents.CLIENT_STARTED.register(client -> service.start());

		// What the Social Tap profile card says: version on top, where you are playing underneath.
		String title = "Minecraft " + FabricLoader.getInstance().getModContainer("minecraft")
				.map(game -> game.getMetadata().getVersion().getFriendlyString()).orElse("");
		int[] ticks = {0};
		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			if (ticks[0]++ % 20 == 0) service.setActivity(title.strip(), describeActivity(client));
		});
		ClientLifecycleEvents.CLIENT_STOPPING.register(client -> service.shutdown());
	}

	/** The server address in multiplayer; "Singleplayer" and the game mode otherwise. */
	private static String describeActivity(Minecraft client) {
		if (client.level == null || client.player == null) return "In the menus";
		ServerData server = client.getCurrentServer();
		if (client.hasSingleplayerServer() || server == null) {
			if (!client.hasSingleplayerServer()) return "Multiplayer";
			if (client.level.getLevelData().isHardcore()) return "Singleplayer · Hardcore";
			if (client.gameMode == null) return "Singleplayer";
			String mode = client.gameMode.getPlayerMode().getName();
			return "Singleplayer · " + Character.toUpperCase(mode.charAt(0)) + mode.substring(1);
		}
		if (server.isRealm()) return "Realms";
		if (server.isLan()) return "LAN world";
		return server.ip;
	}

	private static void render(Overlay overlay, GuiGraphics graphics) {
		graphics.pose().pushPose();
		graphics.pose().translate(0f, 0f, OVERLAY_Z);
		overlay.render(new GuiCanvas(graphics));
		graphics.pose().popPose();
		graphics.flush();
	}

	/** Chat feedback for a command, delivered on the client thread. */
	private static Consumer<String> feedback(FabricClientCommandSource source) {
		return message -> Minecraft.getInstance().execute(() -> source.sendFeedback(Component.literal(message)));
	}

	record GuiCanvas(GuiGraphics graphics) implements Overlay.Canvas {
		@Override
		public int width() {
			return graphics.guiWidth();
		}

		/** This version batches fills and text separately; drawing what is queued keeps later fills on top. */
		@Override
		public void layer() {
			graphics.flush();
		}

		@Override
		public void clip(int x1, int y1, int x2, int y2) {
			graphics.enableScissor(x1, y1, x2, y2);
		}

		@Override
		public void endClip() {
			graphics.disableScissor();
		}

		@Override
		public int height() {
			return graphics.guiHeight();
		}

		@Override
		public void fill(int x1, int y1, int x2, int y2, int argb) {
			graphics.fill(x1, y1, x2, y2, argb);
		}

		@Override
		public void text(String text, float x, float y, float scale, int argb) {
			Font font = Minecraft.getInstance().font;
			graphics.pose().pushPose();
			graphics.pose().translate(x, y, 0f);
			graphics.pose().scale(scale, scale, 1f);
			graphics.drawString(font, text, 0, 0, argb, false);
			graphics.pose().popPose();
		}

		@Override
		public int textWidth(String text) {
			return Minecraft.getInstance().font.width(text);
		}
	}
}
