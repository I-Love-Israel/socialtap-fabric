package social.socialtap.mc;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import social.socialtap.core.ChatPanel;

/** The Social Tap window for Minecraft 1.21.4: hands everything to the shared {@link ChatPanel}. */
final class SocialTapScreen extends Screen {
	private final ChatPanel panel;
	private final KeyMapping key;

	SocialTapScreen(ChatPanel panel, KeyMapping key) {
		super(Component.literal("Social Tap"));
		this.panel = panel;
		this.key = key;
	}

	@Override
	public void added() {
		panel.setKeyName(key.getTranslatedKeyMessage().getString());
		panel.opened();
	}

	@Override
	public void removed() {
		panel.closed();
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	@Override
	public void renderBackground(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
		// The panel dims the game itself; no menu blur.
	}

	@Override
	public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
		panel.render(new SocialTapClient.GuiCanvas(graphics), mouseX, mouseY);
		graphics.flush();
	}

	@Override
	public boolean mouseClicked(double x, double y, int button) {
		return panel.mouseClicked(x, y, button) || super.mouseClicked(x, y, button);
	}

	@Override
	public boolean mouseScrolled(double x, double y, double horizontal, double vertical) {
		return panel.mouseScrolled(x, y, vertical) || super.mouseScrolled(x, y, horizontal, vertical);
	}

	@Override
	public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
		// The open key closes it again, unless you are in the middle of typing.
		if (key.matches(keyCode, scanCode) && panel.inputEmpty()) {
			onClose();
			return true;
		}
		return panel.keyPressed(keyCode, modifiers) || super.keyPressed(keyCode, scanCode, modifiers);
	}

	@Override
	public boolean charTyped(char character, int modifiers) {
		return panel.charTyped(String.valueOf(character)) || super.charTyped(character, modifiers);
	}
}
