package social.socialtap.mc;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import social.socialtap.core.ChatPanel;

/** The Social Tap window for Minecraft 26.2: hands everything to the shared {@link ChatPanel}. */
final class SocialTapScreen extends Screen {
	private final ChatPanel panel;
	private final KeyMapping key;

	SocialTapScreen(ChatPanel panel, KeyMapping key) {
		super(Component.literal("Social Tap"));
		this.panel = panel;
		this.key = key;
	}

	@Override
	public void added() {
		panel.setKeyName(key.getTranslatedKeyMessage().getString());
		panel.opened();
	}

	@Override
	public void removed() {
		panel.closed();
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	@Override
	public void extractBackground(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
		// The panel dims the game itself; no menu blur.
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
		panel.render(new SocialTapClient.GuiCanvas(graphics), mouseX, mouseY);
	}

	@Override
	public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
		return panel.mouseClicked(event.x(), event.y(), event.button()) || super.mouseClicked(event, doubleClick);
	}

	@Override
	public boolean mouseScrolled(double x, double y, double horizontal, double vertical) {
		return panel.mouseScrolled(x, y, vertical) || super.mouseScrolled(x, y, horizontal, vertical);
	}

	@Override
	public boolean keyPressed(KeyEvent event) {
		// The open key closes it again, unless you are in the middle of typing.
		if (key.matches(event) && panel.inputEmpty()) {
			onClose();
			return true;
		}
		return panel.keyPressed(event.key(), event.modifiers()) || super.keyPressed(event);
	}

	@Override
	public boolean charTyped(CharacterEvent event) {
		return panel.charTyped(event.codepointAsString()) || super.charTyped(event);
	}
}
