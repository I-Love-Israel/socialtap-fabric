package social.socialtap.mc;

import java.util.function.Consumer;

import com.mojang.brigadier.arguments.BoolArgumentType;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.ClientCommands;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents;
import net.fabricmc.fabric.api.event.client.player.ClientPreAttackCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Util;
import social.socialtap.core.Overlay;
import social.socialtap.core.SocialTapService;

/** Minecraft 26.2 wiring: where the overlay is drawn and where its clicks come from. */
public class SocialTapClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		SocialTapService service = new SocialTapService(FabricLoader.getInstance().getConfigDir(),
				url -> Util.getPlatform().openUri(url));
		Overlay overlay = service.overlay();

		// In the world with no menu open: drawn over the rest of the HUD.
		HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("socialtap", "overlay"), (graphics, delta) -> {
			if (Minecraft.getInstance().gui.screen() == null) overlay.render(new GuiCanvas(graphics));
		});

		// With any menu open (pause, chat, inventory, title screen): drawn over it, and clickable.
		ScreenEvents.AFTER_INIT.register((client, screen, width, height) -> {
			ScreenEvents.afterExtract(screen).register((current, graphics, mouseX, mouseY, delta) ->
					overlay.render(new GuiCanvas(graphics)));
			ScreenMouseEvents.allowMouseClick(screen).register((current, click) ->
					!(click.button() == 0 && overlay.screenClick(click.x(), click.y())));
		});

		// A new left click in the world lands on whatever is in the middle of the screen.
		ClientPreAttackCallback.EVENT.register((client, player, clickCount) -> clickCount > 0 && overlay.attackClick());

		ClientCommandRegistrationCallback.EVENT.register((dispatcher, context) -> dispatcher.register(
				ClientCommands.literal("socialtap")
						.then(ClientCommands.literal("login").executes(command -> {
							service.login(feedback(command.getSource()));
							return 1;
						}))
						.then(ClientCommands.literal("logout").executes(command -> {
							service.logout(feedback(command.getSource()));
							return 1;
						}))
						.then(ClientCommands.literal("status").executes(command -> {
							service.status(feedback(command.getSource()));
							return 1;
						}))
						.then(ClientCommands.literal("hangup").executes(command -> {
							service.hangUp();
							return 1;
						}))
						.then(ClientCommands.literal("answer").executes(command -> {
							service.answerRinging(feedback(command.getSource()));
							return 1;
						}))
						.then(ClientCommands.literal("decline").executes(command -> {
							service.declineRinging(feedback(command.getSource()));
							return 1;
						}))
						.then(ClientCommands.literal("obnoxious")
								.executes(command -> {
									service.obnoxious(null, feedback(command.getSource()));
									return 1;
								})
								.then(ClientCommands.argument("enabled", BoolArgumentType.bool()).executes(command -> {
									service.obnoxious(BoolArgumentType.getBool(command, "enabled"), feedback(command.getSource()));
									return 1;
								})))
						.then(ClientCommands.literal("activity")
								.executes(command -> {
									service.activity(null, feedback(command.getSource()));
									return 1;
								})
								.then(ClientCommands.argument("enabled", BoolArgumentType.bool()).executes(command -> {
									service.activity(BoolArgumentType.getBool(command, "enabled"), feedback(command.getSource()));
									return 1;
								})))
						.then(ClientCommands.literal("test")
								.then(ClientCommands.literal("call").executes(command -> {
									service.testCall();
									return 1;
								}))
								.then(ClientCommands.literal("message").executes(command -> {
									service.testMessage();
									return 1;
								})))));

		ClientLifecycleEvents.CLIENT_STARTED.register(client -> service.start());

		// What the Social Tap profile card says: version on top, where you are playing underneath.
		String title = "Minecraft " + FabricLoader.getInstance().getModContainer("minecraft")
				.map(game -> game.getMetadata().getVersion().getFriendlyString()).orElse("");
		int[] ticks = {0};
		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			if (ticks[0]++ % 20 == 0) service.setActivity(title.strip(), describeActivity(client));
		});
		ClientLifecycleEvents.CLIENT_STOPPING.register(client -> service.shutdown());
	}

	/** The server address in multiplayer; "Singleplayer" and the game mode otherwise. */
	private static String describeActivity(Minecraft client) {
		if (client.level == null || client.player == null) return "In the menus";
		ServerData server = client.getCurrentServer();
		if (client.hasSingleplayerServer() || server == null) {
			if (!client.hasSingleplayerServer()) return "Multiplayer";
			if (client.level.getLevelData().isHardcore()) return "Singleplayer · Hardcore";
			if (client.gameMode == null) return "Singleplayer";
			String mode = client.gameMode.getPlayerMode().getName();
			return "Singleplayer · " + Character.toUpperCase(mode.charAt(0)) + mode.substring(1);
		}
		if (server.isRealm()) return "Realms";
		if (server.isLan()) return "LAN world";
		return server.ip;
	}

	/** Chat feedback for a command, delivered on the client thread. */
	private static Consumer<String> feedback(FabricClientCommandSource source) {
		return message -> Minecraft.getInstance().execute(() -> source.sendFeedback(Component.literal(message)));
	}

	private record GuiCanvas(GuiGraphicsExtractor graphics) implements Overlay.Canvas {
		@Override
		public int width() {
			return graphics.guiWidth();
		}

		@Override
		public int height() {
			return graphics.guiHeight();
		}

		@Override
		public void fill(int x1, int y1, int x2, int y2, int argb) {
			graphics.fill(x1, y1, x2, y2, argb);
		}

		@Override
		public void text(String text, float x, float y, float scale, int argb) {
			Font font = Minecraft.getInstance().font;
			graphics.pose().pushMatrix();
			graphics.pose().translate(x, y);
			graphics.pose().scale(scale, scale);
			graphics.text(font, text, 0, 0, argb, false);
			graphics.pose().popMatrix();
		}

		@Override
		public int textWidth(String text) {
			return Minecraft.getInstance().font.width(text);
		}
	}
}
